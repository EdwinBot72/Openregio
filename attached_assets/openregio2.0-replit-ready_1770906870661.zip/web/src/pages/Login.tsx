import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { login } from "../api";
import { setToken } from "../auth";

export default function Login() {
  const [email, setEmail] = useState("");
  const [postcode, setPostcode] = useState("");
  const nav = useNavigate();

  async function onSubmit() {
    const r = await login(email, postcode || undefined);
    if (r?.token) {
      setToken(r.token);
      nav("/app");
    } else {
      alert("Login failed");
    }
  }

  return (
    <div className="container">
      <div className="card" style={{maxWidth:520, margin:"0 auto"}}>
        <h2 style={{marginTop:0}}>Inloggen</h2>
        <div className="muted">MVP login: e-mail + (optioneel) postcode voor regiokeuze.</div>
        <div style={{marginTop:12}} className="grid">
          <input className="input" placeholder="E-mail" value={email} onChange={(e)=>setEmail(e.target.value)} />
          <input className="input" placeholder="Postcode (optioneel)" value={postcode} onChange={(e)=>setPostcode(e.target.value)} />
          <button className="btn primary" onClick={onSubmit}>Verder</button>
        </div>
        <div className="muted small" style={{marginTop:10}}>
          Later: magic link + echte sessies.
        </div>
      </div>
    </div>
  );
}
