import pdf from 'pdf-parse';

export async function extractTextFromPDF(buffer) {
  const data = await pdf(buffer);
  const text = (data.text || '').trim();
  const needsOcr = text.length < 200;
  return { text, needsOcr, pages: data.numpages || null };
}
