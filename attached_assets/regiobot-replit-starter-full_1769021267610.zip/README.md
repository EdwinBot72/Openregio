# RegioBot — Replit starter (FULL)

Express + Postgres/pgvector + RAG + Basis/Pro signup (lead-only of checkout redirect).

## Quick start
1) Maak een Node.js Repl
2) Upload + extract deze zip
3) Shell:
```bash
cd server
npm i
cp .env.example .env
npm run migrate
npm run dev
```

## Vereist
- Postgres met pgvector (Neon/Supabase/Render)
- OPENAI_API_KEY

## Test
```bash
curl http://localhost:3000/health
```
