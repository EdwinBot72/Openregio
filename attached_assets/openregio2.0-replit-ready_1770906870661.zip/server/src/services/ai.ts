import OpenAI from "openai";

const key = process.env.OPENAI_API_KEY || "";
const client = key ? new OpenAI({ apiKey: key }) : null;

export async function summarizeText(text: string): Promise<string> {
  if (!client) return "";
  const safe = text.slice(0, 12000);

  const r = await client.responses.create({
    model: "gpt-4.1-mini",
    input: [
      {
        role: "system",
        content: "Vat de tekst kort samen (max 6 bullets) in helder Nederlands voor ondernemers. Geen juridisch advies."
      },
      {
        role: "user",
        content: safe
      }
    ]
  });

  // @ts-ignore
  const out = r.output_text || "";
  return out.trim();
}
