import { chatAnswer, embedTexts } from '../openai.js';
import { vectorSearch } from './retrieve.js';

const SYSTEM = `
Jij bent RegioBot. Jij werkt dossier-gedreven.

Regels (hard):
- Gebruik uitsluitend de meegegeven CONTEXT. Niks verzinnen.
- Als iets niet in context staat: zeg 'Niet in dossier' en noem welke documenten je moet opvragen (Woo).
- Citeer bronnen als: [chunk:<id> | doc:<titel> | datum:<YYYY-MM-DD?>]
- Schrijf compact, zakelijk, in normaal Nederlands.
`;

export async function ask({ org_id, query, k }) {
  const [qEmb] = await embedTexts([query]);
  const rows = await vectorSearch({ org_id, embedding: qEmb, k });

  const context = rows.map(r => {
    const date = r.letter_date ? String(r.letter_date).slice(0,10) : 'onbekend';
    return `SOURCE [chunk:${r.chunk_id} | doc:${r.title || r.document_id} | datum:${date} | score:${Number(r.score).toFixed(3)}]\n${r.text}`;
  });

  const answer = await chatAnswer({ system: SYSTEM, user: query, context });

  return {
    answer,
    sources: rows.map(r => ({
      chunk_id: r.chunk_id,
      document_id: r.document_id,
      title: r.title,
      letter_date: r.letter_date,
      score: Number(r.score),
    })),
  };
}
