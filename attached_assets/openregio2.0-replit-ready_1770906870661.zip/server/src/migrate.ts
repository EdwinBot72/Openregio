import { sqliteRaw } from "./db";
import { users, templates, documents, monitorItems } from "./schema";

// super simple migration (idempotent-ish)
sqliteRaw.exec(`
CREATE TABLE IF NOT EXISTS users (
  id TEXT PRIMARY KEY,
  email TEXT NOT NULL UNIQUE,
  created_at INTEGER NOT NULL,
  region TEXT NOT NULL DEFAULT 'Nederland'
);

CREATE TABLE IF NOT EXISTS monitor_items (
  id TEXT PRIMARY KEY,
  region TEXT NOT NULL,
  title TEXT NOT NULL,
  summary TEXT NOT NULL,
  source_url TEXT,
  created_at INTEGER NOT NULL,
  tags TEXT NOT NULL DEFAULT ''
);

CREATE TABLE IF NOT EXISTS templates (
  id TEXT PRIMARY KEY,
  slug TEXT NOT NULL UNIQUE,
  title TEXT NOT NULL,
  body TEXT NOT NULL,
  created_at INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS documents (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL,
  region TEXT NOT NULL,
  filename TEXT NOT NULL,
  mime TEXT NOT NULL,
  path TEXT NOT NULL,
  created_at INTEGER NOT NULL,
  summary TEXT NOT NULL DEFAULT '',
  tags TEXT NOT NULL DEFAULT ''
);
`);

const now = Date.now();

// seed 1 template if empty
const count = sqliteRaw.prepare("SELECT COUNT(*) as c FROM templates").get() as any;
if (count.c === 0) {
  sqliteRaw.prepare("INSERT INTO templates (id, slug, title, body, created_at) VALUES (?, ?, ?, ?, ?)").run(
    crypto.randomUUID(),
    "woo-zuiver",
    "Woo-verzoek (zuiver)",
`Geachte heer/mevrouw,

Hierbij maak ik gebruik van mijn recht op openbaarheid van bestuur op grond van de Wet open overheid (Woo).
Ik verzoek om openbaarmaking van alle documenten en gegevens met betrekking tot {{onderwerp}} in de periode {{periode}} binnen {{gemeente}}.

Dit verzoek omvat in ieder geval, maar is niet beperkt tot:
{{scope}}

Ik verzoek u de gevraagde informatie per post te verstrekken op:
{{postadres}}
{{woonplaats}}

Met vriendelijke groet,
{{naam}}`,
    now
  );
}

// seed 3 monitor items if empty
const c2 = sqliteRaw.prepare("SELECT COUNT(*) as c FROM monitor_items").get() as any;
if (c2.c === 0) {
  const ins = sqliteRaw.prepare("INSERT INTO monitor_items (id, region, title, summary, source_url, created_at, tags) VALUES (?, ?, ?, ?, ?, ?, ?)");
  ins.run(crypto.randomUUID(), "Nederland", "Nieuwe beleidsupdate (demo)", "Dit is een demo item. Vervang dit met echte feeds later.", "", now, "beleid,demo");
  ins.run(crypto.randomUUID(), "Amsterdam", "Vergunningen update (demo)", "Voorbeeld van regionale filtering op Amsterdam.", "", now-86400000, "vergunning,demo");
  ins.run(crypto.randomUUID(), "Haarlem", "WOO publicatie (demo)", "Voorbeeld: WOO publicatie voor Haarlem.", "", now-172800000, "woo,demo");
}

console.log("✅ DB ready");
