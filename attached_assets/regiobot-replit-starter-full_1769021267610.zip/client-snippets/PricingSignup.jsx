import React, { useMemo, useState } from "react";

const PLANS = [
  {
    id: "basis",
    name: "Basis",
    price: "€12,95",
    period: "/ maand",
    desc: "Lokaal zichtbaar + offline-proof badges. Simpel starten.",
    bullets: [
      "Profiel + regio + categorie",
      "Badges: cash/bonnen/offline/noodstroom",
      "Printbare ledenlijst + templates",
      "Maandelijks opzegbaar"
    ],
    cta: "Start Basis"
  },
  {
    id: "pro",
    name: "Pro",
    price: "€24",
    period: "/ maand",
    highlight: true,
    desc: "Extra zichtbaarheid + prioriteit. Voor ondernemers die sneller willen.",
    bullets: [
      "Alles van Basis",
      "Pro zichtbaarheid (bovenaan in regio)",
      "Prioriteit support / intake",
      "Early access nieuwe features"
    ],
    cta: "Start Pro"
  }
];

function cx(...c) { return c.filter(Boolean).join(" "); }

export default function PricingSignup({
  apiBase = "",
  endpoint = "/api/leads",
  checkoutEndpoint = "/api/checkout/start",
  checkoutMode = "lead_only" // lead_only | checkout
}) {
  const [plan, setPlan] = useState("pro");
  const [loading, setLoading] = useState(false);
  const [ok, setOk] = useState(false);
  const [msg, setMsg] = useState("");

  const [form, setForm] = useState({
    name: "",
    email: "",
    company: "",
    phone: "",
    region: "",
    category: "",
    badges: [],
    note: ""
  });

  const selectedPlan = useMemo(() => PLANS.find(p => p.id === plan), [plan]);

  async function submit(e) {
    e.preventDefault();
    setOk(false);
    setMsg("");

    if (!form.name || !form.email || !form.company) {
      setMsg("Naam, e-mail en bedrijfsnaam zijn verplicht.");
      return;
    }

    setLoading(true);
    try {
      const res = await fetch(apiBase + endpoint, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ plan, ...form, source: "openregio-homepage" })
      });
      const json = await res.json();
      if (!res.ok) throw new Error(json?.error || "Fout bij inschrijven");

      if (checkoutMode === "lead_only") {
        setOk(true);
        setMsg("Inschrijving binnen. We pakken 'm op.");
        return;
      }

      if (json.redirect_url) {
        window.location.href = json.redirect_url;
        return;
      }

      // Stripe flow
      const r2 = await fetch(apiBase + checkoutEndpoint, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ plan, lead_id: json.lead_id })
      });
      const j2 = await r2.json();
      if (!r2.ok) throw new Error(j2?.error || "Checkout fout");
      window.location.href = j2.redirect_url;
    } catch (e2) {
      setMsg(String(e2.message || e2));
    } finally {
      setLoading(false);
    }
  }

  return (
    <section id="wordlid" className="mx-auto max-w-6xl px-4 pb-12">
      <div className="rounded-3xl border border-white/10 bg-white/5 p-8">
        <div>
          <div className="text-sm font-semibold text-white/80">Lid worden</div>
          <h3 className="mt-2 text-3xl font-semibold tracking-tight text-white">
            Kies Basis of Pro. Klaar.
          </h3>
          <p className="mt-2 text-sm text-white/70">
            Basis = snel zichtbaar. Pro = extra grip & voorrang.
          </p>
        </div>

        <div className="mt-6 grid gap-4 lg:grid-cols-2">
          {PLANS.map((p) => {
            const active = plan === p.id;
            return (
              <button
                key={p.id}
                type="button"
                onClick={() => setPlan(p.id)}
                className={cx(
                  "text-left rounded-2xl border p-6 transition",
                  active ? "border-white/30 bg-white/10" : "border-white/10 bg-black/30 hover:bg-white/5"
                )}
              >
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <div className="text-sm font-semibold text-white/80">
                      {p.name}
                      {p.highlight && (
                        <span className="ml-2 inline-flex items-center rounded-full bg-[#8665C0] px-2 py-0.5 text-xs font-semibold text-white">
                          Aanrader
                        </span>
                      )}
                    </div>
                    <div className="mt-1 flex items-end gap-2">
                      <div className="text-3xl font-semibold text-white">{p.price}</div>
                      <div className="text-sm text-white/60">{p.period}</div>
                    </div>
                    <div className="mt-2 text-sm text-white/70">{p.desc}</div>
                  </div>
                  <div className={cx("mt-1 h-5 w-5 rounded-full border", active ? "border-white/40 bg-[#8665C0]" : "border-white/15")} />
                </div>

                <ul className="mt-4 space-y-2 text-sm text-white/70">
                  {p.bullets.map((b) => (
                    <li key={b} className="flex gap-2">
                      <span className="mt-1 inline-block h-1.5 w-1.5 rounded-full bg-white/50" />
                      <span>{b}</span>
                    </li>
                  ))}
                </ul>
              </button>
            );
          })}
        </div>

        <form onSubmit={submit} className="mt-8 grid gap-4">
          <div className="grid gap-4 sm:grid-cols-2">
            <input className="w-full rounded-xl border border-white/10 bg-black/40 px-3 py-2 text-sm text-white outline-none"
              placeholder="Naam"
              value={form.name}
              onChange={(e) => setForm(p => ({...p, name: e.target.value}))}
            />
            <input className="w-full rounded-xl border border-white/10 bg-black/40 px-3 py-2 text-sm text-white outline-none"
              placeholder="E-mail"
              value={form.email}
              onChange={(e) => setForm(p => ({...p, email: e.target.value}))}
            />
          </div>

          <div className="grid gap-4 sm:grid-cols-2">
            <input className="w-full rounded-xl border border-white/10 bg-black/40 px-3 py-2 text-sm text-white outline-none"
              placeholder="Bedrijfsnaam"
              value={form.company}
              onChange={(e) => setForm(p => ({...p, company: e.target.value}))}
            />
            <input className="w-full rounded-xl border border-white/10 bg-black/40 px-3 py-2 text-sm text-white outline-none"
              placeholder="Telefoon (optioneel)"
              value={form.phone}
              onChange={(e) => setForm(p => ({...p, phone: e.target.value}))}
            />
          </div>

          <textarea className="w-full rounded-xl border border-white/10 bg-black/40 px-3 py-2 text-sm text-white outline-none"
            placeholder="Opmerking (optioneel)"
            rows={3}
            value={form.note}
            onChange={(e) => setForm(p => ({...p, note: e.target.value}))}
          />

          {msg && (
            <div className={cx("rounded-xl border px-4 py-3 text-sm", ok ? "border-emerald-400/20 bg-emerald-400/10 text-emerald-200" : "border-white/10 bg-white/5 text-white/80")}>
              {msg}
            </div>
          )}

          <button
            type="submit"
            disabled={loading}
            className={cx("rounded-xl px-4 py-2 text-sm font-semibold text-white bg-[#8665C0] hover:opacity-90", loading && "opacity-60")}
          >
            {loading ? "Bezig..." : `${selectedPlan?.cta} →`}
          </button>

          <div className="text-xs text-white/50">
            Checkout gedrag: <b>{checkoutMode}</b>
          </div>
        </form>
      </div>
    </section>
  );
}
