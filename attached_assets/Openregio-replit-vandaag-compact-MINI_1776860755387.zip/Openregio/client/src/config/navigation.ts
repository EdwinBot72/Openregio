import {
  CalendarDays,
  TrendingUp,
  Scale,
  BarChart3,
  User,
  ShieldCheck,
  BarChart2,
  Users,
  FileText,
  Building2,
  Settings,
} from "lucide-react";

export type NavSubItem = {
  title: string;
  url: string;
  icon: React.ElementType;
  proOnly?: boolean;
  adminOnly?: boolean;
  comingSoon?: boolean;
};

export type NavSection = {
  id: string;
  title: string;
  icon: React.ElementType;
  url?: string;
  sub?: NavSubItem[];
  adminOnly?: boolean;
};

/** Compacte hoofdnavigatie — zo min mogelijk kliklagen */
export const MAIN_NAV: NavSection[] = [
  {
    id: "vandaag",
    title: "Vandaag",
    icon: CalendarDays,
    url: "/vandaag",
  },
  {
    id: "kansen",
    title: "Kansen",
    icon: TrendingUp,
    url: "/kansen/opdrachten",
  },
  {
    id: "regels",
    title: "Regels",
    icon: Scale,
    url: "/regels/updates",
  },
  {
    id: "groei",
    title: "Groei",
    icon: BarChart3,
    url: "/groei/profiel",
  },
  {
    id: "account",
    title: "Account",
    icon: User,
    url: "/account/instellingen",
  },
  {
    id: "beheer",
    title: "Beheer",
    icon: ShieldCheck,
    adminOnly: true,
    sub: [
      { title: "Beheer dashboard", url: "/admin", icon: BarChart2 },
      { title: "Gebruikers", url: "/admin/users", icon: Users },
      { title: "Ondernemers", url: "/admin/ondernemers", icon: Building2 },
      { title: "Content", url: "/admin/blogs", icon: FileText },
      { title: "Regio & WOO", url: "/admin/woo", icon: FileText },
      { title: "Systeem", url: "/admin/inzicht", icon: Settings },
    ],
  },
];

export const ACCOUNT_NAV = [
  { title: "Instellingen", url: "/account/instellingen", icon: Settings },
];

export const KERN_NAV = MAIN_NAV;
export const GROEI_NAV: NavSection[] = [];
export const EXTRA_NAV: NavSection[] = [];
export const APP_NAV: NavSection[] = MAIN_NAV;
