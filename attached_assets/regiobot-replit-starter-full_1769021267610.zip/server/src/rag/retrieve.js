import { sql } from '../db.js';

export async function vectorSearch({ org_id, embedding, k = 8 }) {
  const q = `
    SELECT
      c.id as chunk_id,
      c.text,
      c.metadata_json,
      d.id as document_id,
      d.title,
      d.letter_date,
      1 - (e.embedding <=> $1::vector) AS score
    FROM embeddings e
    JOIN chunks c ON c.id = e.chunk_id
    JOIN documents d ON d.id = c.document_id
    WHERE d.org_id = $2
    ORDER BY e.embedding <=> $1::vector
    LIMIT $3
  `;
  const res = await sql(q, [embedding, org_id, k]);
  return res.rows;
}
