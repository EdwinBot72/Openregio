import 'dotenv/config';
import express from 'express';
import cors from 'cors';

import { uploadMiddleware, uploadDocument } from './routes/documents.js';
import { askRoute } from './routes/ask.js';
import { searchRoute } from './routes/search.js';
import { createLead } from './routes/leads.js';
import { startCheckout } from './routes/checkout.js';

const app = express();
app.use(cors());
app.use(express.json({ limit: '2mb' }));

app.get('/health', (_req, res) => res.json({ ok: true }));

app.post('/api/documents/upload', uploadMiddleware, uploadDocument);
app.post('/api/ask', askRoute);
app.get('/api/search', searchRoute);

app.post('/api/leads', createLead);
app.post('/api/checkout/start', startCheckout);

const port = Number(process.env.PORT || 3000);
app.listen(port, () => console.log('RegioBot server on', port));
