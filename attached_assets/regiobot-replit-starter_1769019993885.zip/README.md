# RegioBot – Replit starter

Express + pgvector + RAG + Basis/Pro signup.

## Quick start
cd server
npm i
cp .env.example .env
npm run migrate
npm run dev
