import Database from "better-sqlite3";
import { drizzle } from "drizzle-orm/better-sqlite3";
import path from "path";
import fs from "fs";

const dataDir = path.join(process.cwd(), "data");
if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir, { recursive: true });

const dbFile = path.join(dataDir, "app.db");
const sqlite = new Database(dbFile);

// Basic pragmas for dev
sqlite.pragma("journal_mode = WAL");

export const db = drizzle(sqlite);
export const sqliteRaw = sqlite;
