import 'dotenv/config';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { sql } from './db.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function run() {
  const dir = path.join(__dirname, '../migrations');
  const files = fs.readdirSync(dir).filter(f => f.endsWith('.sql')).sort();
  for (const f of files) {
    const content = fs.readFileSync(path.join(dir, f), 'utf8');
    console.log('Running migration:', f);
    await sql(content);
  }
  console.log('Migrations done.');
  process.exit(0);
}

run().catch((e) => {
  console.error(e);
  process.exit(1);
});
