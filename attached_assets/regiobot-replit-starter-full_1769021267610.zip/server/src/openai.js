const BASE = process.env.OPENAI_BASE_URL || 'https://api.openai.com/v1';

function headers() {
  if (!process.env.OPENAI_API_KEY) throw new Error('OPENAI_API_KEY ontbreekt');
  return {
    'Content-Type': 'application/json',
    'Authorization': `Bearer ${process.env.OPENAI_API_KEY}`,
  };
}

export async function embedTexts(texts) {
  const model = process.env.EMBEDDING_MODEL || 'text-embedding-3-small';
  const res = await fetch(`${BASE}/embeddings`, {
    method: 'POST',
    headers: headers(),
    body: JSON.stringify({ model, input: texts }),
  });
  if (!res.ok) throw new Error(`Embeddings error: ${res.status} ${await res.text()}`);
  const json = await res.json();
  return json.data.map(d => d.embedding);
}

export async function chatAnswer({ system, user, context }) {
  const model = process.env.CHAT_MODEL || 'gpt-4.1-mini';
  const messages = [{ role: 'system', content: system }];
  if (context?.length) {
    messages.push({ role: 'system', content: `CONTEXT\n${context.join('\n\n')}` });
  }
  messages.push({ role: 'user', content: user });

  const res = await fetch(`${BASE}/chat/completions`, {
    method: 'POST',
    headers: headers(),
    body: JSON.stringify({ model, temperature: 0.2, messages }),
  });
  if (!res.ok) throw new Error(`Chat error: ${res.status} ${await res.text()}`);
  const json = await res.json();
  return json.choices?.[0]?.message?.content?.trim() || '';
}
