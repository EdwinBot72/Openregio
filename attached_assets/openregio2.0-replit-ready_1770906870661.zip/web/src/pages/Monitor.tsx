import { useEffect, useState } from "react";
import { getToken } from "../auth";
import { me, getMonitor } from "../api";

export default function Monitor() {
  const token = getToken()!;
  const [region, setRegion] = useState("Nederland");
  const [items, setItems] = useState<any[]>([]);

  useEffect(() => {
    (async () => {
      const r = await me(token);
      const reg = r?.user?.region || "Nederland";
      setRegion(reg);
      const m = await getMonitor(reg);
      setItems(m?.items || []);
    })();
  }, []);

  return (
    <div className="container">
      <div className="card">
        <h2 style={{marginTop:0}}>Beleidsmonitor — {region}</h2>
        <div className="muted">MVP feed. Later: automatische bronnen + alerts.</div>
      </div>

      <div className="grid" style={{marginTop:16}}>
        {items.map((it) => (
          <div key={it.id} className="card">
            <div style={{display:"flex", justifyContent:"space-between", gap:12, flexWrap:"wrap"}}>
              <b>{it.title}</b>
              <span className="badge">{(it.tags || "").split(",")[0] || "update"}</span>
            </div>
            <div className="muted" style={{marginTop:8}}>{it.summary}</div>
            {it.sourceUrl ? (
              <div style={{marginTop:10}}>
                <a className="btn" href={it.sourceUrl} target="_blank" rel="noreferrer">Bron</a>
              </div>
            ) : null}
          </div>
        ))}
        {items.length === 0 ? (
          <div className="card">
            <b>Geen items</b>
            <div className="muted" style={{marginTop:6}}>Maak demo-items aan via Admin.</div>
          </div>
        ) : null}
      </div>
    </div>
  );
}
