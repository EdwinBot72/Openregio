import { embedTexts } from '../openai.js';
import { vectorSearch } from '../rag/retrieve.js';

export async function searchRoute(req, res) {
  try {
    const org_id = req.query.org_id;
    const q = req.query.q;
    const k = Number(req.query.k || 10);
    if (!org_id) return res.status(400).json({ error: 'org_id required' });
    if (!q) return res.status(400).json({ error: 'q required' });

    const [emb] = await embedTexts([q]);
    const rows = await vectorSearch({ org_id, embedding: emb, k });
    return res.json({ results: rows });
  } catch (e) {
    console.error(e);
    return res.status(500).json({ error: String(e.message || e) });
  }
}
