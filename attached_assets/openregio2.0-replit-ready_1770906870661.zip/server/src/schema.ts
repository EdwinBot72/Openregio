import { sqliteTable, text, integer } from "drizzle-orm/sqlite-core";

export const users = sqliteTable("users", {
  id: text("id").primaryKey(),
  email: text("email").notNull().unique(),
  createdAt: integer("created_at").notNull(),
  region: text("region").notNull().default("Nederland"),
});

export const monitorItems = sqliteTable("monitor_items", {
  id: text("id").primaryKey(),
  region: text("region").notNull(),
  title: text("title").notNull(),
  summary: text("summary").notNull(),
  sourceUrl: text("source_url"),
  createdAt: integer("created_at").notNull(),
  tags: text("tags").notNull().default(""),
});

export const templates = sqliteTable("templates", {
  id: text("id").primaryKey(),
  slug: text("slug").notNull().unique(),
  title: text("title").notNull(),
  body: text("body").notNull(),
  createdAt: integer("created_at").notNull(),
});

export const documents = sqliteTable("documents", {
  id: text("id").primaryKey(),
  userId: text("user_id").notNull(),
  region: text("region").notNull(),
  filename: text("filename").notNull(),
  mime: text("mime").notNull(),
  path: text("path").notNull(),
  createdAt: integer("created_at").notNull(),
  summary: text("summary").notNull().default(""),
  tags: text("tags").notNull().default(""),
});
