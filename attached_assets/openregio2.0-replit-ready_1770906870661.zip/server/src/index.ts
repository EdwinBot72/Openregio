import "dotenv/config";
import express from "express";
import cors from "cors";
import multer from "multer";
import path from "path";
import fs from "fs";
import { z } from "zod";
import { db, sqliteRaw } from "./db";
import { regionFromPostcode } from "./util/region";
import { summarizeText } from "./services/ai";

import { users, templates, documents, monitorItems } from "./schema";
import { eq, desc, and } from "drizzle-orm";

import "./migrate";

const app = express();
app.use(cors());
app.use(express.json({ limit: "5mb" }));

const PORT = Number(process.env.PORT || 3001);

app.get("/health", (_, res) => res.json({ ok: true }));

// --- Auth-lite (MVP) ---
// POST /api/auth/login { email, postcode? }
app.post("/api/auth/login", async (req, res) => {
  const schema = z.object({ email: z.string().email(), postcode: z.string().optional() });
  const body = schema.safeParse(req.body);
  if (!body.success) return res.status(400).json({ error: "invalid" });

  const { email, postcode } = body.data;
  const region = postcode ? regionFromPostcode(postcode) : "Nederland";

  const existing = await db.select().from(users).where(eq(users.email, email));
  if (existing.length === 0) {
    await db.insert(users).values({ id: crypto.randomUUID(), email, createdAt: Date.now(), region });
  } else if (postcode) {
    await sqliteRaw.prepare("UPDATE users SET region=? WHERE email=?").run(region, email);
  }

  // fake session token: email (for MVP). Replace with real auth later.
  res.json({ ok: true, token: email, region });
});

// GET /api/me (token in Authorization: Bearer <email>)
app.get("/api/me", async (req, res) => {
  const auth = req.headers.authorization || "";
  const token = auth.replace("Bearer ", "").trim();
  if (!token) return res.status(401).json({ error: "no_token" });

  const me = await db.select().from(users).where(eq(users.email, token));
  if (!me[0]) return res.status(401).json({ error: "unknown" });
  res.json({ user: me[0] });
});

// --- Monitor feed ---
app.get("/api/monitor", async (req, res) => {
  const region = String(req.query.region || "Nederland");
  const rows = await db
    .select()
    .from(monitorItems)
    .where(region === "Nederland" ? undefined as any : eq(monitorItems.region, region))
    .orderBy(desc(monitorItems.createdAt));
  res.json({ items: rows });
});

// Admin create monitor item (MVP no auth gate)
app.post("/api/monitor", async (req, res) => {
  const schema = z.object({
    region: z.string().min(2),
    title: z.string().min(2),
    summary: z.string().min(2),
    sourceUrl: z.string().optional(),
    tags: z.string().optional()
  });
  const body = schema.safeParse(req.body);
  if (!body.success) return res.status(400).json({ error: "invalid" });

  const item = { id: crypto.randomUUID(), createdAt: Date.now(), ...body.data, sourceUrl: body.data.sourceUrl || "", tags: body.data.tags || "" };
  await db.insert(monitorItems).values({
    id: item.id,
    region: item.region,
    title: item.title,
    summary: item.summary,
    sourceUrl: item.sourceUrl,
    createdAt: item.createdAt,
    tags: item.tags
  });
  res.json({ ok: true, item });
});

// --- Templates ---
app.get("/api/templates", async (_, res) => {
  const rows = await db.select().from(templates).orderBy(desc(templates.createdAt));
  res.json({ templates: rows });
});

app.post("/api/templates/:slug/render", async (req, res) => {
  const slug = req.params.slug;
  const t = await db.select().from(templates).where(eq(templates.slug, slug));
  if (!t[0]) return res.status(404).json({ error: "not_found" });

  const vars = req.body || {};
  const rendered = t[0].body.replace(/\{\{(\w+)\}\}/g, (_m, key) => String(vars[key] ?? ""));
  res.json({ title: t[0].title, rendered });
});

// --- Documents upload + library ---
const uploadDir = path.join(process.cwd(), "uploads");
if (!fs.existsSync(uploadDir)) fs.mkdirSync(uploadDir, { recursive: true });
const upload = multer({ dest: uploadDir, limits: { fileSize: 20 * 1024 * 1024 } });

app.post("/api/documents/upload", upload.single("file"), async (req, res) => {
  const auth = req.headers.authorization || "";
  const token = auth.replace("Bearer ", "").trim();
  if (!token) return res.status(401).json({ error: "no_token" });

  const me = await db.select().from(users).where(eq(users.email, token));
  if (!me[0]) return res.status(401).json({ error: "unknown" });

  const file = req.file;
  if (!file) return res.status(400).json({ error: "no_file" });

  const tags = String(req.body.tags || "");
  const region = me[0].region || "Nederland";

  const id = crypto.randomUUID();
  const rec = {
    id,
    userId: me[0].id,
    region,
    filename: file.originalname,
    mime: file.mimetype,
    path: file.path,
    createdAt: Date.now(),
    tags,
    summary: ""
  };

  await db.insert(documents).values({
    id: rec.id,
    userId: rec.userId,
    region: rec.region,
    filename: rec.filename,
    mime: rec.mime,
    path: rec.path,
    createdAt: rec.createdAt,
    tags: rec.tags,
    summary: rec.summary
  });

  res.json({ ok: true, doc: rec });
});

app.get("/api/documents", async (req, res) => {
  const auth = req.headers.authorization || "";
  const token = auth.replace("Bearer ", "").trim();
  if (!token) return res.status(401).json({ error: "no_token" });

  const me = await db.select().from(users).where(eq(users.email, token));
  if (!me[0]) return res.status(401).json({ error: "unknown" });

  const region = String(req.query.region || me[0].region || "Nederland");

  const rows = await db
    .select()
    .from(documents)
    .where(and(eq(documents.userId, me[0].id), region === "Nederland" ? undefined as any : eq(documents.region, region)))
    .orderBy(desc(documents.createdAt));

  res.json({ docs: rows });
});

// Optional: AI summarize doc text (MVP: user pastes text)
app.post("/api/documents/:id/summarize", async (req, res) => {
  const auth = req.headers.authorization || "";
  const token = auth.replace("Bearer ", "").trim();
  if (!token) return res.status(401).json({ error: "no_token" });

  const me = await db.select().from(users).where(eq(users.email, token));
  if (!me[0]) return res.status(401).json({ error: "unknown" });

  const id = req.params.id;
  const schema = z.object({ text: z.string().min(50) });
  const body = schema.safeParse(req.body);
  if (!body.success) return res.status(400).json({ error: "invalid" });

  const sum = await summarizeText(body.data.text);
  await sqliteRaw.prepare("UPDATE documents SET summary=? WHERE id=?").run(sum, id);

  res.json({ ok: true, summary: sum });
});

app.listen(PORT, () => console.log(`✅ OpenRegio API listening on :${PORT}`));
