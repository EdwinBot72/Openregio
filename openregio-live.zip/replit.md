# OpenRegio - Cooperative Platform for Local Entrepreneurs

## Overview

OpenRegio is a Dutch cooperative platform designed to empower local entrepreneurs by offering an alternative to large tech platforms. It provides tools for business networking, AI-powered marketing, and a democratic governance model. Members can create profiles, collaborate, leverage AI for content and SEO, and participate in platform decision-making through a proposal voting system. The platform aims to foster a community-first approach with a professional, robust, and scalable full-stack application.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

The frontend is built with React and TypeScript, using Vite for development and Wouter for routing. State management is handled by TanStack Query. Styling is implemented with Tailwind CSS, leveraging a custom design system based on shadcn/ui and Radix UI primitives, with a professional aesthetic and HSL-based color system supporting light/dark themes. Key patterns include atomic design and a multi-select onboarding flow.

### Backend Architecture

The backend uses Express.js with TypeScript, following a RESTful API design. It features stateless JWT-based authentication and Zod for request/response validation. Data access is abstracted via an `IStorage` interface, with `DbStorage` using Drizzle ORM for PostgreSQL and `MemStorage` for development. All entities use UUIDs as primary keys.

### Data Storage Solutions

PostgreSQL, accessed via Drizzle ORM, is the primary database. Key data models include business profiles, proposals, votes, blogs, activities, and user profiles with `pain points` and `onboarding_tokens`. For RAG, the `pgvector` extension stores `rag_documents`, `rag_chunks`, and `rag_embeddings` (1536-dimensional vectors from OpenAI's text-embedding-3-small). Leads data is also stored.

### Authentication and Authorization

The system implements JWT authentication with short-lived access tokens and rotating refresh tokens for security. `bcrypt` handles password hashing. Rate limiting is applied to login/registration. Role-Based Access Control (`requirePro`, `requireAdmin` middleware) restricts features by plan and admin status. All auth logic is consolidated in `server/jwtAuth.ts` — dead legacy files (`simpleAuth.ts`, `auth.ts`, `middleware/auth.ts`) have been removed. Admin detection uses `user.role === "admin" || user.role === "master"` (DB-driven, no hardcoded emails). The master account has `role: "master"`.

### Core Features

-   **RegioBot with RAG**: A regional WOO & Legal AI assistant using Retrieval-Augmented Generation for dossier-driven answers. It processes user-uploaded documents (PDF, images with OCR, text) by chunking and embedding them with OpenAI's `text-embedding-3-small`, storing them via `pgvector` for semantic search. Answers are generated using `gpt-4o-mini` with source citations. It focuses on wet- en regelgeving analysis, WOO-verzoeken, mandates, and authorities, explicitly refusing non-business queries. This is a PRO-exclusive feature.
-   **WOO Categories**: Enforced database categorization for WOO requests, allowing specific categories and blocking personal/non-business queries.
-   **Privacy & Consent Dashboard (AVG/GDPR Compliance)**: Allows users to manage data visibility, view consent logs, export data, and perform soft account deletion. PRO members have enhanced customization options.
-   **Affiliate System**: Tracks referrals and calculates recurring commissions for members.
-   **Object Storage**: Personal file storage for entrepreneurs using Replit's built-in Object Storage (Google Cloud Storage) with public and private directories, tracked in a `user_files` database table. It uses a two-step presigned URL upload flow.
-   **Email Integration**: Implemented via SMTP for welcome messages, password resets, notifications, and newsletters.
-   **TenderNed Integration**: Displays live public tenders from Dutch municipalities via the TenderNed public API, with in-memory caching and pre-filling based on user profiles.
-   **Brief Analyse**: An AI function using Gemini 2.5-flash (with gpt-4o-mini fallback) to analyze government letters, extracting key information like sender, document type, legal basis, and recommended actions.
-   **Gemeente-updates**: Displays official publications per municipality from the KOOP SRU API (overheid.nl), with in-memory caching and search functionality.
-   **Regio Deals**: Manages exclusive member deals and collective agreements via a `regio_deals` database table, with admin management and a dedicated member interface.
-   **Admin Cockpit**: Central admin dashboard at `/admin` with platform stats and navigation to all admin sections. Sub-pages: Woo-monitoring (`/admin/woo`), Regio-beheer (`/admin/regios`), Platform-inzicht (`/admin/inzicht`), Gebruikers (`/admin/users`), Ondernemers (`/admin/ondernemers`), Blogs, Commissies, Regio Deals. All require `requireAdmin` middleware. The Ondernemers page is GDPR-compliant, showing businessName, region, plan, memberSince (month/year), and isRecentlyActive (based on refresh tokens).
-   **Navigation Config**: Data-driven navigation via `client/src/config/navigation.ts` (MAIN_NAV = 5 hoofdsecties + Beheer). AppSidebar consumes MAIN_NAV. De 5 secties zijn: 1) Vandaag (`/vandaag`, `/vandaag/updates`, `/vandaag/acties`), 2) Kansen (`/kansen/opdrachten`, `/kansen/subsidies`, `/kansen/in-de-buurt`, `/kansen/samenwerkingen`), 3) Regels (`/regels/updates`, `/regels/check`, `/regels/documenten`, `/regels/woo`), 4) Groei (`/groei/zichtbaarheid`, `/groei/profiel`, `/groei/website-check`), 5) Mijn account (`/account/voortgang`, `/account/instellingen`, `/account/affiliate`). Legacy-URLs redirecten automatisch naar de nieuwe structuur.
-   **Kansen-radar (Aan de slag)**: AI-generated daily opportunity tip based on Dutch national news (NOS, NU.nl RSS feeds via Gemini 2.5-flash). Card renamed "Kansen van vandaag", 24h in-memory cache, opportunity-focused prompt.
-   **Lokaal Ondernemen Check (/basischeck)**: Public 8-question self-assessment about local business orientation, scoring 0–8, with tailored improvement tips per "nee" answer.
-   **Koop Lokaal (/koop-lokaal)**: Public business discovery directory listing `lokaal_aanbod` entries categorized by type.
-   **Lokale Marktplaats (/lokaal-marktplaats)**: Authenticated B2B marketplace for "ik zoek / ik bied" listings; uses `lokaal_aanbod` table with enum types (zoek/bied) and categories.
-   **Lokale Acties (/lokale-acties)**: Pro-leden maken evenementen/initiatieven aan (titel, beschrijving, datum, locatie, doelgroep, externeLink, contactEmail). Basic+Pro browsen lijst met filters (regio/doelgroep/zoek) en sorteer-dropdown (datum/regio). Klik op een kaart opent een detail-modal. Compacte preview op `/vandaag` is gescoped op `user.region` (fallback: landelijke top-3) en toont voor Basic-leden een expliciete upgrade-teaser. Auto-expiry: `expiresAt` = datum (indien gegeven) of createdAt+30d. Eigen bewerken/verwijderen/markeer-verlopen. Tabel: `lokale_acties` (auto-gemigreerd via `server/db-migrate.ts`). API: `GET/POST/PATCH/DELETE /api/lokale-acties` + `POST /:id/verlopen`. Mutaties (POST/PATCH/DELETE/verlopen) vereisen `requirePro` middleware; PATCH whitelisted alleen wijzigbare velden (geen `ownerUserId` of `status`).
-   **Hulp-engine dossiers (/regels/help)**: Antwoorden + scenario-uitkomst van de hulp-flows (brief-ontvangen, regel-onduidelijk, controle-vergunning-boete) kunnen door ingelogde gebruikers worden bewaard via "Bewaar als dossier". Opslag in `help_flow_dossiers` (jsonb-antwoorden + scenario + concept-tekst). Op `/regels/help` staat een "Mijn dossiers"-sectie met openen-knop (`?dossier=<id>` herstelt antwoorden in de runner) en verwijderen-actie. API: `GET/POST/DELETE /api/help-flow-dossiers`.
-   **Blog-doelgroepen (publiek vs leden)**: De `blogs`-tabel heeft een `audience`-veld (`publiek` | `leden`, default `publiek`). `/api/blogs/public` en `/api/blogs/public/:slug` tonen voor anonieme bezoekers alleen `publiek`-blogs (homepage + /blogs). Leden-updates worden opgehaald via `/api/news/latest` (auth-required) en verschijnen als aparte "Leden-updates"-sectie op `/vandaag`. Admin kan in de blog-editor de doelgroep selecteren.

### Security and Observability

Security measures include HSTS, Content-Security-Policy, secure cookie settings, input sanitization, type validation, and secure file uploads with MIME type validation and random filenames. Observability features structured JSON logging for server errors and client-side error boundaries.

## Product Strategie — 3 Killer Features

- **Simpele regel**: Basis = kijken en meedoen, Pro = tools gebruiken en initiatieven starten
- **Feature matrix**:
  | Feature | Basis | Pro |
  |---|---|---|
  | Regio-inzicht | ✔ | ✔ uitgebreid |
  | Brief analyse | ✔ beperkt | ✔ volledig |
  | RegioBot | ✔ beperkt | ✔ onbeperkt |
  | Woo uitleg | ✔ | ✔ |
  | Woo-verzoek maken | ❌ | ✔ |
  | Woo dossiers | ❌ | ✔ |
  | Bedrijfsprofiel | ✔ basis | ✔ uitgebreid |
  | Website onderhoud | ❌ | ✔ |
  | Samenwerken meedoen | ✔ | ✔ |
  | Project starten | ❌ | ✔ |

## Homepage Redesign (March 2026)

Nieuwe 7-sectie opbouw op basis van structuurdocument:
- **Hero**: "Grip op regels, zichtbaarheid en ondernemerschap in je regio." — knoppen: Bekijk dashboard + Ontdek wat er speelt; hero-card met 4 feature-rijen
- **Het probleem**: 4 probleemkaarten (regels, brieven, digitaal, administratie)
- **Regio-analyse**: interactieve AI-tool (behouden)
- **Wat OpenRegio doet**: 3 grote oplossingsblokken (brieven/regels, zichtbaarheid, samenwerking)
- **GROW-sectie**: donkerblauwe sectie met G/R/O/W acronym
- **Dashboard uitleg**: uitleg + CSS-mockup van dashboard
- **Voor wie**: 4 doelgroepkaarten
- **Membership + CTA**: prijskaarten behouden, CTA aangepast naar "Start met OpenRegio"

## Startup & Portability Hardening (March 2026)

- Early env validation in `server/index.ts`: DATABASE_URL + SESSION_SECRET → process.exit(1) on missing; optional vars (MOLLIE, POSTMARK, OPENAI, GEMINI) → warn only
- `server/seed.ts`: non-fatal (removed throw); master account seed wrapped in try/catch in routes.ts
- `package-lock.json` regenerated fresh (687 entries, lockfileVersion 3) to fix cross-platform `npm ci` compatibility
- `.env.example` documents required vs optional environment variables
- JWT: 15min access + 7-day rotating refresh tokens; no auto-refresh in frontend (redirects to /login)

## External Dependencies

-   **Database**: Neon Database (PostgreSQL), pgvector
-   **AI Integration**: OpenAI (text-embedding-3-small, gpt-4o-mini), Gemini 2.5-flash, tesseract.js (for OCR)
-   **UI Components**: Radix UI, shadcn/ui, Lucide React, cmdk, embla-carousel, vaul
-   **Build Tools**: Vite, esbuild, tsx
-   **Styling**: Tailwind CSS
-   **Utilities**: date-fns, clsx, tailwind-merge, zod, react-hook-form
-   **Object Storage**: Replit's built-in Object Storage (Google Cloud Storage)
-   **Email Service**: SMTP (via mail.mijndomein.nl)
-   **External APIs**: TenderNed public API, KOOP SRU API (overheid.nl)
## E2E tests (Playwright)

De vier OpenRegio-pagina's (Vandaag, Netwerk, RegioBot, Lidmaatschap) hebben Playwright e2e-tests in `e2e/`. Draai ze met `scripts/run-e2e.sh` of `npx playwright test` tegen een lokale dev-server (port 5000).

- Configuratie: `playwright.config.ts`
- Helpers: `e2e/helpers.ts` (registreert + logt een gebruiker in via /api/auth en injecteert cookies)
- Spec-bestanden: `e2e/lidmaatschap.spec.ts`, `e2e/network.spec.ts`, `e2e/regiobot.spec.ts`, `e2e/vandaag.spec.ts`
- Server: in non-production zijn de auth rate-limiters opgehoogd zodat tests veel registraties achter elkaar kunnen doen (zie `server/jwtAuth.ts` E2E_BYPASS_RATE_LIMITS).

## CI Slack-meldingen activeren

De GitHub Actions workflow (`.github/workflows/e2e.yml`) stuurt automatisch een Slack-bericht wanneer de e2e-tests falen of herstellen. Dit werkt alleen als het secret `SLACK_WEBHOOK_URL` in de GitHub-repo is ingesteld.

### Stap 1 — Maak een Slack Incoming Webhook aan

1. Ga naar [api.slack.com/apps](https://api.slack.com/apps) en klik op **Create New App → From scratch**.
2. Geef de app een naam (bv. *OpenRegio CI*) en kies de gewenste workspace.
3. Ga in het linkermenu naar **Incoming Webhooks** en zet de schakelaar op **On**.
4. Klik op **Add New Webhook to Workspace**, kies het kanaal waar meldingen naartoe moeten (bv. `#dev-alerts`) en klik op **Allow**.
5. Kopieer de gegenereerde Webhook URL (begint met `https://hooks.slack.com/services/...`).

### Stap 2 — Voeg het secret toe aan de GitHub-repo

1. Ga naar de GitHub-repo → **Settings → Secrets and variables → Actions**.
2. Klik op **New repository secret**.
3. Naam: `SLACK_WEBHOOK_URL`
4. Waarde: de gekopieerde webhook URL uit stap 1.
5. Klik op **Add secret**.

Vanaf de volgende push stuurt de workflow Slack-berichten bij een mislukte of herstelde run. Als `SLACK_WEBHOOK_URL` niet is ingesteld, slaat de workflow de notificatie stil over (geen fout).

### Stap 3 — Verifieer de melding handmatig

Om te controleren of de koppeling werkt zonder te wachten op een echte fout:

1. Open een van de spec-bestanden, bv. `e2e/vandaag.spec.ts`.
2. Voeg tijdelijk een altijd-falende assertion toe:
   ```ts
   test('force-fail voor Slack-test', async () => {
     expect(true).toBe(false);
   });
   ```
3. Commit en push naar een branch — de run faalt en je ontvangt een Slack-melding.
4. Verwijder de tijdelijke test, commit en push opnieuw — de run slaagt en je ontvangt de herstelmelding.

### Herstelmelding (rood → groen)

De "weer groen"-melding wordt **alleen** verstuurd als de vorige voltooide run op **dezelfde branch** de conclusie `failure` had. Bij een eerste groene run op een nieuwe branch, of als de vorige run al geslaagd was, wordt geen herstelmelding verzonden.
