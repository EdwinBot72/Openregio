# OpenRegio 2.0 (Replit-ready)

**Wat je krijgt (MVP):**
- Publieke homepage met **Regio-check** (postcode → regio label) + CTA naar login
- Login (super simpel tokenless demo: kies e-mail → doorgaan)
- Dashboard (na login): Regio-overzicht + snelle acties
- RegioBot: **Woo-template generator** + document upload (PDF/ZIP) + AI-samenvatting (optioneel)
- WOO-bibliotheek: lijst van uploads + tags + samenvatting
- Monitor: "Beleidsupdates" feed (MVP: handmatig items aanmaken)

## 1) Run lokaal / Replit
1. `npm install`
2. `npm run dev`

Web draait op `http://localhost:5173`  
API draait op `http://localhost:3001`

## 2) Environment
Kopieer `.env.example` in `server/.env`

- `DATABASE_URL` is niet nodig (we gebruiken SQLite)
- `OPENAI_API_KEY` is optioneel (als leeg: geen AI-samenvatting)

## 3) Database
SQLite file staat in `server/data/app.db` (automatisch aangemaakt).

## 4) Deploy
- `npm run build`
- `npm start`

## 5) Waar je als volgende mee kunt opschalen
- Echte auth (magic link)
- Postgres i.p.v. SQLite
- Scrapers: WOO/overheid publicaties + vergunningen feeds
- Alerts: mail + in-app notificaties per regio/branche
