import { sql } from '../db.js';

let stripeClient = null;
async function getStripe() {
  if (!process.env.STRIPE_SECRET_KEY) throw new Error('STRIPE_SECRET_KEY ontbreekt');
  if (!stripeClient) {
    const mod = await import('stripe');
    stripeClient = new mod.default(process.env.STRIPE_SECRET_KEY);
  }
  return stripeClient;
}

export async function startCheckout(req, res) {
  try {
    const { plan, lead_id } = req.body || {};
    if (!plan || !['basis','pro'].includes(plan)) return res.status(400).json({ error: 'plan must be basis|pro' });

    const price = plan === 'basis' ? process.env.STRIPE_PRICE_ID_BASIS : process.env.STRIPE_PRICE_ID_PRO;
    if (!price) return res.status(400).json({ error: 'Stripe price id missing' });

    const stripe = await getStripe();
    const session = await stripe.checkout.sessions.create({
      mode: 'subscription',
      line_items: [{ price, quantity: 1 }],
      success_url: process.env.STRIPE_SUCCESS_URL || 'https://example.com/success',
      cancel_url: process.env.STRIPE_CANCEL_URL || 'https://example.com/cancel',
      metadata: { plan, lead_id: lead_id || '' },
    });

    await sql(`INSERT INTO audit_logs (org_id, action, payload) VALUES (NULL,'checkout_started',$1)`, [
      JSON.stringify({ plan, lead_id, session_id: session.id })
    ]);

    return res.json({ redirect_url: session.url });
  } catch (e) {
    console.error(e);
    return res.status(500).json({ error: String(e.message || e) });
  }
}
