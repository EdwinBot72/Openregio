import { sql } from '../db.js';

function pickRedirect(plan) {
  const provider = process.env.CHECKOUT_PROVIDER || 'redirect';
  if (provider === 'paypro') {
    return plan === 'basis' ? process.env.PAYPRO_URL_BASIS : process.env.PAYPRO_URL_PRO;
  }
  if (provider === 'stripe') return null; // handled by /api/checkout/start
  return plan === 'basis' ? process.env.CHECKOUT_URL_BASIS : process.env.CHECKOUT_URL_PRO;
}

export async function createLead(req, res) {
  try {
    const { plan, name, email, company, phone, region, category, badges, note, source } = req.body || {};
    if (!plan || !['basis','pro'].includes(plan)) return res.status(400).json({ error: 'plan must be basis|pro' });
    if (!name || !email || !company) return res.status(400).json({ error: 'name,email,company required' });

    const leadRes = await sql(
      `INSERT INTO leads (plan, name, email, company, phone, region, category, badges, note, source)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10) RETURNING id`,
      [plan, name, email, company, phone || null, region || null, category || null, JSON.stringify(badges || []), note || null, source || 'openregio-homepage']
    );

    const mode = process.env.CHECKOUT_MODE || 'lead_only';
    if (mode === 'checkout') {
      const redirect_url = pickRedirect(plan);
      return res.json({ ok: true, lead_id: leadRes.rows[0].id, redirect_url });
    }
    return res.json({ ok: true, lead_id: leadRes.rows[0].id });
  } catch (e) {
    console.error(e);
    return res.status(500).json({ error: String(e.message || e) });
  }
}
