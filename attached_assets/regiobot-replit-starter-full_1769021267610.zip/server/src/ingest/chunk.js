function estimateTokens(str) {
  const words = (str || '').trim().split(/\s+/).filter(Boolean).length;
  return Math.ceil(words / 0.75);
}

export function chunkText(text, { maxTokens = 1100, overlapTokens = 220 } = {}) {
  const lines = (text || '').split(/\r?\n/);
  const blocks = [];
  let buf = [];
  let bufTok = 0;

  const pushBuf = () => {
    const t = buf.join('\n').trim();
    if (t) blocks.push(t);
    buf = [];
    bufTok = 0;
  };

  for (const line of lines) {
    const l = line.replace(/\s+$/,'');
    const isHardSplit = /^\s*(Geachte|Betreft|Onderwerp|Besluit|Kenmerk|Zaaknummer|Datum|Artikel\s+\d+)/i.test(l);
    const lt = estimateTokens(l);

    if (isHardSplit && bufTok > maxTokens * 0.6) pushBuf();
    if (bufTok + lt > maxTokens && buf.length) pushBuf();

    buf.push(l);
    bufTok += lt;
  }
  pushBuf();

  if (overlapTokens <= 0 || blocks.length <= 1) return blocks;

  const out = [];
  for (let i = 0; i < blocks.length; i++) {
    if (i === 0) out.push(blocks[i]);
    else {
      const prev = out[out.length - 1];
      const overlap = prev.slice(Math.max(0, prev.length - 1200));
      out.push((overlap + '\n' + blocks[i]).trim());
    }
  }
  return out;
}
