import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { getToken } from "../auth";
import { me, getMonitor, listDocs } from "../api";

export default function Dashboard() {
  const token = getToken()!;
  const [region, setRegion] = useState("Nederland");
  const [kpis, setKpis] = useState({ monitor: 0, docs: 0 });

  useEffect(() => {
    (async () => {
      const r = await me(token);
      const user = r?.user;
      const reg = user?.region || "Nederland";
      setRegion(reg);

      const m = await getMonitor(reg);
      const d = await listDocs(token, reg);
      setKpis({ monitor: (m?.items?.length || 0), docs: (d?.docs?.length || 0) });
    })();
  }, []);

  return (
    <div className="container">
      <div className="layout">
        <aside className="side sidebar">
          <div className="card">
            <b>Jouw regio</b>
            <div className="muted" style={{marginTop:6}}>{region}</div>
            <hr />
            <div className="small muted">Snelle acties</div>
            <div className="grid" style={{marginTop:10}}>
              <Link className="btn" to="/app/monitor">Open Monitor</Link>
              <Link className="btn" to="/app/regiobot">Open RegioBot</Link>
              <Link className="btn" to="/app/library">WOO-bibliotheek</Link>
              <Link className="btn" to="/app/admin">Admin</Link>
            </div>
          </div>
        </aside>

        <main>
          <div className="card">
            <h2 style={{marginTop:0}}>Welkom, ondernemer</h2>
            <div className="muted">
              Kies wat je nu wilt doen. Geen omwegen. Direct aan de slag.
            </div>
          </div>

          <div className="grid" style={{gridTemplateColumns:"repeat(3, 1fr)", marginTop:16}}>
            <div className="card">
              <b>Beleidsmonitor</b>
              <div className="muted" style={{marginTop:6}}>
                Updates voor <b>{region}</b>. Vandaag: <b>{kpis.monitor}</b> items.
              </div>
              <div style={{marginTop:10}}>
                <Link className="btn primary" to="/app/monitor">Bekijk updates</Link>
              </div>
            </div>
            <div className="card">
              <b>RegioBot</b>
              <div className="muted" style={{marginTop:6}}>
                Genereer een zuiver Woo-verzoek en houd het menselijk en feitelijk.
              </div>
              <div style={{marginTop:10}}>
                <Link className="btn primary" to="/app/regiobot">Open RegioBot</Link>
              </div>
            </div>
            <div className="card">
              <b>WOO-bibliotheek</b>
              <div className="muted" style={{marginTop:6}}>
                Jouw uploads in deze regio: <b>{kpis.docs}</b>.
              </div>
              <div style={{marginTop:10}}>
                <Link className="btn primary" to="/app/library">Open bibliotheek</Link>
              </div>
            </div>
          </div>

          <div className="card" style={{marginTop:16}}>
            <b>Menselijke maat</b>
            <div className="muted" style={{marginTop:6}}>
              OpenRegio helpt met inzicht en templates. Jij verstuurt zelf. Geen vertegenwoordiging, geen juridische adviespraktijk.
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}
