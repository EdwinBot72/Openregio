import bcrypt from "bcrypt";
import { storage } from "./storage";

const SALT_ROUNDS = 10;

// ─── MASTER ACCOUNT ──────────────────────────────────────────────────────────
// Wachtwoord wordt geladen uit MASTER_PASSWORD env-variabele.
// Stel dit in als Replit Secret: MASTER_PASSWORD=jouw-veilig-wachtwoord
export async function seedMasterAccount() {
  const masterEmail = process.env.MASTER_EMAIL || "edwin@stroombox.nl";
  const masterPassword = process.env.MASTER_PASSWORD;

  if (!masterPassword) {
    console.warn(
      "[Seed] MASTER_PASSWORD niet ingesteld — master account wordt niet aangemaakt of bijgewerkt."
    );
    return;
  }

  try {
    const existingMaster = await storage.getUserByEmail(masterEmail);

    if (existingMaster) {
      if (existingMaster.plan !== "pro" || existingMaster.role !== "master") {
        await storage.updateUser(existingMaster.id, { plan: "pro", role: "master" });
        console.log("✓ Master account bijgewerkt naar pro/master:", existingMaster.email);
      } else {
        console.log("✓ Master account bestaat al:", existingMaster.email);
      }
      return;
    }

    const passwordHash = await bcrypt.hash(masterPassword, SALT_ROUNDS);

    const masterUser = await storage.createUser({
      email: masterEmail,
      passwordHash,
      plan: "pro",
      role: "master",
      firstName: "Edwin",
      lastName: "Stroombox",
    });

    console.log("✓ Master account aangemaakt:", masterUser.email, "met rol:", masterUser.role);
  } catch (error) {
    console.error("[Seed] Master account seed mislukt (niet fataal):", (error as Error).message || error);
  }
}

// ─── TEST SEED ────────────────────────────────────────────────────────────────
// Alleen uitvoeren als NODE_ENV=test of TEST_SEED=true.
// Maakt drie testgebruikers aan: admin, pro en basic.
// NOOIT in productie uitvoeren.
export async function seedTestAccounts() {
  if (process.env.NODE_ENV !== "test" && process.env.TEST_SEED !== "true") {
    return;
  }

  console.log("[TestSeed] Testgebruikers aanmaken...");

  const accounts = [
    {
      email: "admin@test.openregio.nl",
      password: "TestAdmin123!",
      plan: "pro" as const,
      role: "admin" as const,
      firstName: "Test",
      lastName: "Admin",
    },
    {
      email: "pro@test.openregio.nl",
      password: "TestPro123!",
      plan: "pro" as const,
      role: "member" as const,
      firstName: "Test",
      lastName: "Pro",
    },
    {
      email: "basic@test.openregio.nl",
      password: "TestBasic123!",
      plan: "basic" as const,
      role: "member" as const,
      firstName: "Test",
      lastName: "Basic",
    },
  ];

  for (const account of accounts) {
    try {
      const existing = await storage.getUserByEmail(account.email);
      if (existing) {
        console.log(`[TestSeed] Bestaat al: ${account.email}`);
        continue;
      }

      const passwordHash = await bcrypt.hash(account.password, SALT_ROUNDS);
      await storage.createUser({
        email: account.email,
        passwordHash,
        plan: account.plan,
        role: account.role,
        firstName: account.firstName,
        lastName: account.lastName,
        mustCompleteOnboarding: false,
      });
      console.log(`[TestSeed] ✓ Aangemaakt: ${account.email} (${account.plan}/${account.role})`);
    } catch (error) {
      console.error(`[TestSeed] Mislukt voor ${account.email}:`, error);
    }
  }
}
