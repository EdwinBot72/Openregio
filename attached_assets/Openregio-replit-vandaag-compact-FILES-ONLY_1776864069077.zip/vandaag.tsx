import { Link } from "wouter";
import { usePageTitle } from "@/hooks/usePageTitle";
import {
  Bell,
  CheckCircle2,
  FolderKanban,
  TrendingUp,
  FileText,
  Megaphone,
  MessageSquare,
  ArrowRight,
} from "lucide-react";

type StatCardProps = {
  title: string;
  value: string;
  sublabel: string;
  icon: React.ElementType;
};

type SimpleCardProps = {
  badge: string;
  badgeClass: string;
  title: string;
  description: string;
  cta: string;
};

function StatCard({ title, value, sublabel, icon: Icon }: StatCardProps) {
  return (
    <div className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm">
      <div className="mb-3 flex items-center justify-between">
        <span className="text-sm font-medium text-slate-600">{title}</span>
        <div className="rounded-xl bg-sky-50 p-2 text-sky-700">
          <Icon className="h-4 w-4" />
        </div>
      </div>
      <div className="flex items-end gap-2">
        <span className="text-3xl font-bold tracking-tight text-slate-900">{value}</span>
        <span className="pb-1 text-sm text-slate-500">{sublabel}</span>
      </div>
    </div>
  );
}

function PriorityCard({ badge, badgeClass, title, description, cta }: SimpleCardProps) {
  return (
    <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
      <div className={`mb-3 inline-flex rounded-full px-2.5 py-1 text-xs font-semibold ${badgeClass}`}>
        {badge}
      </div>
      <h3 className="mb-2 text-base font-semibold text-slate-900">{title}</h3>
      <p className="mb-4 text-sm leading-6 text-slate-600">{description}</p>
      <button className="inline-flex items-center gap-2 text-sm font-semibold text-sky-700">
        {cta}
        <ArrowRight className="h-4 w-4" />
      </button>
    </div>
  );
}

export default function VandaagPage() {
  usePageTitle("Vandaag");

  return (
    <div className="mx-auto w-full max-w-7xl space-y-6 px-4 py-6 md:px-6" data-testid="page-vandaag">
      <section className="space-y-2">
        <h1 className="text-3xl font-bold tracking-tight text-slate-950">Vandaag</h1>
        <p className="text-sm text-slate-600 md:text-base">
          Dit speelt nu in jouw regio, sector en dossiers.
        </p>
      </section>

      <section className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
        <StatCard title="Updates" value="3" sublabel="nieuw" icon={Bell} />
        <StatCard title="Acties" value="2" sublabel="open" icon={CheckCircle2} />
        <StatCard title="Kansen" value="4" sublabel="relevant" icon={TrendingUp} />
        <StatCard title="Dossiers" value="1" sublabel="lopend" icon={FolderKanban} />
      </section>

      <section className="space-y-4 rounded-3xl border border-slate-200 bg-slate-50/70 p-5 md:p-6">
        <div className="flex items-center justify-between gap-4">
          <div>
            <h2 className="text-xl font-semibold text-slate-950">Wat vraagt nu aandacht?</h2>
            <p className="mt-1 text-sm text-slate-600">
              De belangrijkste signalen en updates voor vandaag.
            </p>
          </div>
          <Link href="/regels/updates" className="hidden text-sm font-semibold text-sky-700 md:inline-flex md:items-center md:gap-2">
            Bekijk alles
            <ArrowRight className="h-4 w-4" />
          </Link>
        </div>

        <div className="grid gap-4 xl:grid-cols-3">
          <PriorityCard
            badge="Regelupdate"
            badgeClass="bg-sky-100 text-sky-800"
            title="Nieuwe terrasregels centrum"
            description="Nieuwe regels kunnen invloed hebben op openingstijden en vergunningvoorwaarden."
            cta="Bekijk update"
          />
          <PriorityCard
            badge="Actie nodig"
            badgeClass="bg-amber-100 text-amber-800"
            title="Antwoord binnen op documentverzoek"
            description="Er is een reactie ontvangen op een verzoek. Kijk wat er is aangeleverd en wat nog ontbreekt."
            cta="Open dossier"
          />
          <PriorityCard
            badge="Kans"
            badgeClass="bg-emerald-100 text-emerald-800"
            title="Lokale zomeractie zoekt partners"
            description="Ondernemers zoeken aansluiting voor een gezamenlijke actie in de regio."
            cta="Bekijk kans"
          />
        </div>
      </section>

      <div className="grid gap-6 xl:grid-cols-[1.4fr_1fr]">
        <section className="rounded-3xl border border-slate-200 bg-white p-5 shadow-sm md:p-6">
          <div className="mb-5 flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
            <div>
              <h2 className="text-xl font-semibold text-slate-950">Samenwerken & vragen</h2>
              <p className="mt-1 text-sm text-slate-600">
                Stel een vraag, plaats een oproep of haak aan bij ondernemers die tegen hetzelfde aanlopen.
              </p>
            </div>
            <div className="flex flex-wrap gap-2">
              <button className="rounded-xl bg-sky-700 px-4 py-2 text-sm font-semibold text-white">Stel een vraag</button>
              <button className="rounded-xl border border-slate-200 bg-white px-4 py-2 text-sm font-semibold text-slate-700">Plaats oproep</button>
              <button className="rounded-xl border border-slate-200 bg-white px-4 py-2 text-sm font-semibold text-slate-700">Bekijk alles</button>
            </div>
          </div>

          <div className="grid gap-4 md:grid-cols-3">
            <div className="rounded-2xl border border-slate-200 p-4">
              <div className="mb-3 inline-flex rounded-xl bg-sky-50 p-2 text-sky-700">
                <MessageSquare className="h-4 w-4" />
              </div>
              <h3 className="mb-2 text-base font-semibold text-slate-900">Wie heeft ervaring met terrasvergunningen?</h3>
              <p className="mb-4 text-sm text-slate-600">Horeca · 2 reacties</p>
              <button className="inline-flex items-center gap-2 text-sm font-semibold text-sky-700">Open <ArrowRight className="h-4 w-4" /></button>
            </div>
            <div className="rounded-2xl border border-slate-200 p-4">
              <div className="mb-3 inline-flex rounded-xl bg-emerald-50 p-2 text-emerald-700">
                <Megaphone className="h-4 w-4" />
              </div>
              <h3 className="mb-2 text-base font-semibold text-slate-900">Gezocht: partner voor lokale flyeractie</h3>
              <p className="mb-4 text-sm text-slate-600">Detailhandel · nieuw</p>
              <button className="inline-flex items-center gap-2 text-sm font-semibold text-sky-700">Bekijk <ArrowRight className="h-4 w-4" /></button>
            </div>
            <div className="rounded-2xl border border-slate-200 p-4">
              <div className="mb-3 inline-flex rounded-xl bg-violet-50 p-2 text-violet-700">
                <FileText className="h-4 w-4" />
              </div>
              <h3 className="mb-2 text-base font-semibold text-slate-900">Meer ondernemers last van afvalheffing</h3>
              <p className="mb-4 text-sm text-slate-600">4 ondernemers aangehaakt</p>
              <button className="inline-flex items-center gap-2 text-sm font-semibold text-sky-700">Samen oppakken <ArrowRight className="h-4 w-4" /></button>
            </div>
          </div>
        </section>

        <section className="rounded-3xl border border-slate-200 bg-white p-5 shadow-sm md:p-6">
          <div className="mb-4">
            <h2 className="text-xl font-semibold text-slate-950">Acties voor jou</h2>
            <p className="mt-1 text-sm text-slate-600">Concrete vervolgstappen voor vandaag.</p>
          </div>

          <div className="space-y-3">
            {[
              ["Reageer op nieuw document", "hoog"],
              ["Bekijk update over vergunningen", "middel"],
              ["Controleer 2 kansen in jouw regio", "nieuw"],
              ["Werk je bedrijfsprofiel bij", "laag"],
            ].map(([label, status]) => (
              <div key={label} className="flex items-center justify-between gap-3 rounded-2xl border border-slate-200 p-3">
                <div className="flex items-center gap-3">
                  <span className={`h-2.5 w-2.5 rounded-full ${status === "hoog" ? "bg-rose-500" : status === "middel" ? "bg-amber-500" : status === "nieuw" ? "bg-sky-500" : "bg-slate-300"}`} />
                  <span className="text-sm font-medium text-slate-800">{label}</span>
                </div>
                <button className="rounded-xl border border-slate-200 px-3 py-2 text-sm font-semibold text-slate-700">Nu doen</button>
              </div>
            ))}
          </div>
        </section>
      </div>

      <section className="rounded-3xl border border-slate-200 bg-white p-5 shadow-sm md:p-6">
        <div className="mb-5 flex items-center justify-between gap-4">
          <div>
            <h2 className="text-xl font-semibold text-slate-950">Gezamenlijke dossiers</h2>
            <p className="mt-1 text-sm text-slate-600">
              Onderwerpen die meerdere ondernemers raken en gezamenlijk worden uitgezocht.
            </p>
          </div>
          <Link href="/regels/woo" className="hidden text-sm font-semibold text-sky-700 md:inline-flex md:items-center md:gap-2">
            Bekijk alles
            <ArrowRight className="h-4 w-4" />
          </Link>
        </div>

        <div className="grid gap-4 xl:grid-cols-3">
          {[
            ["Handhaving bedrijventerrein", "In opbouw", "Samen documenten verzamelen en helder krijgen hoe uitvoering en beleid op elkaar aansluiten.", "Bekijk dossier"],
            ["Terrasbeleid binnenstad", "Lopend", "Meerdere ondernemers kijken naar impact, uitleg en vervolgstappen.", "Bekijk dossier"],
            ["Afvalheffing ondernemerszone", "Verkennen", "Signalen bundelen en bepalen welke documenten en vragen nodig zijn.", "Aansluiten"],
          ].map(([title, status, desc, cta]) => (
            <div key={title} className="rounded-2xl border border-slate-200 p-5">
              <div className="mb-3 flex items-center justify-between gap-3">
                <h3 className="text-base font-semibold text-slate-900">{title}</h3>
                <span className={`rounded-full px-2.5 py-1 text-xs font-semibold ${status === "Lopend" ? "bg-emerald-100 text-emerald-800" : status === "In opbouw" ? "bg-sky-100 text-sky-800" : "bg-violet-100 text-violet-800"}`}>{status}</span>
              </div>
              <p className="mb-4 text-sm leading-6 text-slate-600">{desc}</p>
              <button className="inline-flex items-center gap-2 text-sm font-semibold text-sky-700">
                {cta}
                <ArrowRight className="h-4 w-4" />
              </button>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}
