import { useEffect, useState } from "react";
import { getToken } from "../auth";
import { me, listDocs, summarizeDoc } from "../api";

export default function Library() {
  const token = getToken()!;
  const [region, setRegion] = useState("Nederland");
  const [docs, setDocs] = useState<any[]>([]);
  const [paste, setPaste] = useState("");
  const [selected, setSelected] = useState<string>("");

  async function refresh(reg: string) {
    const d = await listDocs(token, reg);
    setDocs(d?.docs || []);
  }

  useEffect(() => {
    (async () => {
      const r = await me(token);
      const reg = r?.user?.region || "Nederland";
      setRegion(reg);
      await refresh(reg);
    })();
  }, []);

  async function doSummarize() {
    if (!selected) return alert("Selecteer een document.");
    if (paste.length < 50) return alert("Plak minimaal 50 tekens tekst om samen te vatten (MVP).");
    const r = await summarizeDoc(token, selected, paste);
    if (r.ok) {
      await refresh(region);
      alert("✅ Samenvatting opgeslagen.");
    } else {
      alert("❌ Samenvatting mislukt (check OPENAI_API_KEY in server/.env).");
    }
  }

  return (
    <div className="container">
      <div className="card">
        <h2 style={{marginTop:0}}>WOO-bibliotheek — {region}</h2>
        <div className="muted">
          Uploads + (optioneel) AI-samenvattingen. MVP: je plakt tekst om te summarizen.
        </div>
      </div>

      <div className="grid" style={{gridTemplateColumns:"1fr 1fr", marginTop:16}}>
        <div className="card">
          <b>Documenten</b>
          <div className="muted small" style={{marginTop:6}}>
            Selecteer een document om er een samenvatting aan te hangen.
          </div>

          <div className="grid" style={{marginTop:10}}>
            {docs.map((d) => (
              <div key={d.id} style={{border:"1px solid #e7edf6", borderRadius:12, padding:12}}>
                <div style={{display:"flex", justifyContent:"space-between", gap:10}}>
                  <b style={{fontSize:14}}>{d.filename}</b>
                  <button className="btn" onClick={()=>setSelected(d.id)}>
                    {selected === d.id ? "Geselecteerd" : "Selecteer"}
                  </button>
                </div>
                <div className="muted small" style={{marginTop:6}}>
                  Tags: {d.tags || "-"} · {new Date(d.createdAt).toLocaleString()}
                </div>
                {d.summary ? (
                  <div className="muted" style={{marginTop:10, whiteSpace:"pre-wrap"}}>{d.summary}</div>
                ) : (
                  <div className="muted small" style={{marginTop:10}}>Nog geen samenvatting.</div>
                )}
              </div>
            ))}
            {docs.length === 0 ? (
              <div className="muted">Nog niets geüpload. Ga naar RegioBot → Upload.</div>
            ) : null}
          </div>
        </div>

        <div className="card">
          <b>AI-samenvatting toevoegen</b>
          <div className="muted small" style={{marginTop:6}}>
            MVP: plak relevante tekst uit je document (later: echte PDF parsing).
          </div>
          <textarea className="input" style={{height:320, marginTop:10}} value={paste} onChange={(e)=>setPaste(e.target.value)} placeholder="Plak hier tekst..." />
          <button className="btn primary" style={{marginTop:10}} onClick={doSummarize}>
            Maak samenvatting
          </button>
          <div className="muted small" style={{marginTop:10}}>
            Als OPENAI_API_KEY leeg is, slaat hij geen samenvatting op (maar de bibliotheek werkt wel).
          </div>
        </div>
      </div>
    </div>
  );
}
