export function regionFromPostcode(pc: string): string {
  const x = (pc || "").toUpperCase().replace(/\s+/g, "");
  // MVP mapping: just a few examples; expand later
  if (/^10\d\d/.test(x) || /^11\d\d/.test(x)) return "Amsterdam";
  if (/^20\d\d/.test(x)) return "Haarlem";
  if (/^12\d\d/.test(x)) return "Hilversum";
  if (/^25\d\d/.test(x)) return "Den Haag";
  if (/^30\d\d/.test(x)) return "Rotterdam";
  if (/^56\d\d/.test(x)) return "Eindhoven";
  return "Nederland";
}
