# Woo extractieschema (RegioBot)

Doel: uit een overheidsbrief precies de velden trekken waarmee je een Woo-verzoek strak afbakent.

## JSON schema
```json
{
  "org_name": "",
  "org_department": "",
  "letter_date": "",
  "reference_numbers": [],
  "decision_type": "",
  "decision_subject_line": "",
  "subject_summary": "",
  "topic_tags": [],
  "period_start": "",
  "period_end": "",
  "locations": [],
  "cadastre_refs": [],
  "object_ids": [],
  "explicit_attachments": [],
  "explicit_document_refs": [],
  "implied_processes": [],
  "requested_document_types": [],
  "requester_name": "",
  "requester_email": "",
  "requester_address": "",
  "delivery_preference": "email",
  "format_preference": "native+pdf+metadata",
  "confidence": 0.0,
  "missing_fields": [],
  "quote_snippets": [{ "field": "", "quote": "", "page_hint": "" }]
}
```

## Prompt (copy/paste)
```text
Je taak: extraheer uit de overheidsbrief de velden voor een Woo-verzoek.
Focus: zo precies mogelijk AFBAKENEN (instantie, besluit, kenmerk, periode, objecten, documenttypes).
Regels:
- Alleen invullen wat in de tekst staat of logisch volgt uit genoemde processtappen.
- Als iets ontbreekt: laat leeg en zet veldnaam in missing_fields.
- Voeg per belangrijk veld 1 korte quote toe in quote_snippets (max 20 woorden).
Output: precies het JSON schema, geldig JSON, geen extra tekst.
```
