import { Switch, Route, useRoute, Redirect, useLocation } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { OpenRegioTopNav } from "@/components/OpenRegioTopNav";
import { ErrorBoundary } from "@/components/error-boundary";
import { useAuth } from "@/hooks/useAuth";
import { useContentProtection } from "@/hooks/useContentProtection";
import { Skeleton } from "@/components/ui/skeleton";
import NotFound from "@/pages/not-found";
import HomePage from "@/pages/home";
import LoginPage from "@/pages/login";
import RegisterPage from "@/pages/register";
import DashboardPage from "@/pages/dashboard";
import VandaagPage from "@/pages/vandaag";
import NetworkPage from "@/pages/network";
import CommunityPage from "@/pages/community";
import RegioBotPage from "@/pages/regiobot";
import CooperativePage from "@/pages/cooperative";
import ChatPage from "@/pages/chat";
import OnboardingPage from "@/pages/onboarding";
import LidmaatschapPage from "@/pages/lidmaatschap";
import BedrijfsprofielPage from "@/pages/bedrijfsprofiel";
import BetalingGeslaagdPage from "@/pages/betaling-geslaagd";
import FirstLoginPage from "@/pages/first-login";
import PrivacyPage from "@/pages/privacy";
import VoorwaardenPage from "@/pages/voorwaarden";
import StartPage from "@/pages/start";
import BasischeckPage from "@/pages/basischeck";
import PrivacyDashboardPage from "@/pages/privacy-dashboard";
import ProVisibilitySettingsPage from "@/pages/pro-visibility-settings";
import WooBotPage from "@/pages/woo-bot";
import WooWizardPage from "@/pages/woo-wizard";
import WooBibliotheekPage from "@/pages/woo-bibliotheek";
import RegioCrewPage from "@/pages/regiocrew";
import BlogDetailPage from "@/pages/blog-detail";
import BlogsPage from "@/pages/blogs";
import AdminBlogsPage from "@/pages/admin/blogs";
import AdminCommissionsPage from "@/pages/admin/commissions";
import AdminUsersPage from "@/pages/admin/users";
import AdminIndexPage from "@/pages/admin/index";
import AdminWooPage from "@/pages/admin/woo";
import AdminRegiosPage from "@/pages/admin/regios";
import AdminInzichtPage from "@/pages/admin/inzicht";
import AffiliatePage from "@/pages/affiliate";
import LedenPage from "@/pages/leden";
import ForgotPasswordPage from "@/pages/forgot-password";
import ResetPasswordPage from "@/pages/reset-password";
import DisclaimerPage from "@/pages/disclaimer";
import CookiebeleidPage from "@/pages/cookiebeleid";
import RegioAnalysePage from "@/pages/regio-analyse";
import BeleidsmonitorPage from "@/pages/beleidsmonitor";
import AanbestedingenPage from "@/pages/aanbestedingen";
import GemeenteUpdatesPage from "@/pages/gemeente-updates";
import FinancieringPage from "@/pages/financiering";
import RegiodealsPage from "@/pages/regio-deals";
import RegiodealsAdminPage from "@/pages/admin/regio-deals-admin";
import AdminOndernemersPage from "@/pages/admin/ondernemers";
import AdminIntelPage from "@/pages/admin/intel";
import WebsiteOnderhoudPage from "@/pages/zichtbaarheid/website-onderhoud";
import RegelkaartPage from "@/pages/informatie/regelkaart";
import CheckSituatiePage from "@/pages/actie/check-situatie";
import KennisbankPage from "@/pages/informatie/kennisbank";
import BriefAnalysePage from "@/pages/tools/brief-analyse";
import WebsiteScanPage from "@/pages/tools/website-scan";
import RegelgevingVerkennerPage from "@/pages/regelgeving-verkenner";
import AanDeSlagPage from "@/pages/aan-de-slag";
import KoopLokaalPage from "@/pages/koop-lokaal";
import LokaleBasischeckPage from "@/pages/lokale-basischeck";
import LokaalMarktplaatsPage from "@/pages/lokaal-marktplaats";
import KansenInDeBuurtPage from "@/pages/kansen-in-de-buurt";
import KansenMarktPage from "@/pages/kansen-markt";
import WetgevingIndienenPage from "@/pages/wetgeving-indienen";
import WetgevingPublicatiesPage from "@/pages/wetgeving/publicaties";
import AdminWetgevingPage from "@/pages/admin/wetgeving";
import AdminCursussenPage from "@/pages/admin/cursussen";
import BinnenkortPage from "@/pages/binnenkort";
import RegelsHelpPage from "@/pages/regels-help";
import RegelsHelpFlowPage from "@/pages/regels-help-flow";
import GezondPijlerPage from "@/pages/gezond-pijler";

// Routes that should NOT have the sidebar/header layout
const PUBLIC_ROUTES = ["/", "/login", "/register", "/start", "/lidmaatschap", "/betaling-geslaagd", "/first-login", "/privacy", "/voorwaarden", "/basischeck", "/blog/:slug", "/blogs", "/forgot-password", "/reset-password", "/disclaimer", "/cookiebeleid", "/regio-analyse", "/koop-lokaal", "/gezond/:slug"];

function PublicRouter() {
  return (
    <Switch>
      <Route path="/" component={HomePage} />
      <Route path="/login" component={LoginPage} />
      <Route path="/register" component={RegisterPage} />
      <Route path="/start" component={StartPage} />
      <Route path="/lidmaatschap" component={LidmaatschapPage} />
      <Route path="/betaling-geslaagd" component={BetalingGeslaagdPage} />
      <Route path="/first-login" component={FirstLoginPage} />
      <Route path="/privacy" component={PrivacyPage} />
      <Route path="/voorwaarden" component={VoorwaardenPage} />
      <Route path="/basischeck" component={BasischeckPage} />
      <Route path="/blog/:slug" component={BlogDetailPage} />
      <Route path="/blogs" component={BlogsPage} />
      <Route path="/forgot-password" component={ForgotPasswordPage} />
      <Route path="/reset-password" component={ResetPasswordPage} />
      <Route path="/disclaimer" component={DisclaimerPage} />
      <Route path="/cookiebeleid" component={CookiebeleidPage} />
      <Route path="/regio-analyse" component={RegioAnalysePage} />
      <Route path="/koop-lokaal" component={KoopLokaalPage} />
      <Route path="/gezond/:slug" component={GezondPijlerPage} />
      <Route component={NotFound} />
    </Switch>
  );
}

function AuthenticatedRouter() {
  return (
    <Switch>
      {/* ── Redirects: legacy → nieuwe URLs ─────────────────────────────── */}
      <Route path="/dashboard">
        <Redirect to="/vandaag" />
      </Route>
      <Route path="/intel">
        <Redirect to="/regels/updates" />
      </Route>
      <Route path="/kansen/aanbestedingen">
        <Redirect to="/kansen/opdrachten" />
      </Route>
      <Route path="/kansen-in-de-buurt">
        <Redirect to="/kansen/in-de-buurt" />
      </Route>
      <Route path="/affiliate">
        <Redirect to="/account/affiliate" />
      </Route>
      <Route path="/bedrijfsprofiel">
        <Redirect to="/groei/profiel" />
      </Route>
      <Route path="/privacy-dashboard">
        <Redirect to="/account/instellingen" />
      </Route>
      <Route path="/pro/visibility-settings">
        <Redirect to="/groei/zichtbaarheid" />
      </Route>
      <Route path="/tools/website-scan">
        <Redirect to="/groei/website-check" />
      </Route>
      <Route path="/tools/brief-analyse">
        <Redirect to="/regels/documenten" />
      </Route>
      <Route path="/actie/check">
        <Redirect to="/regels/check" />
      </Route>
      <Route path="/woo-bibliotheek">
        <Redirect to="/regels/woo" />
      </Route>
      <Route path="/cursussen">
        <Redirect to="/vandaag" />
      </Route>
      <Route path="/kansen/financiering">
        <Redirect to="/kansen/subsidies" />
      </Route>

      {/* ── Basis-sectie redirects ────────────────────────────────────────── */}
      <Route path="/kansen">
        <Redirect to="/kansen/opdrachten" />
      </Route>
      <Route path="/regels">
        <Redirect to="/regels/updates" />
      </Route>
      <Route path="/groei">
        <Redirect to="/groei/profiel" />
      </Route>
      <Route path="/account">
        <Redirect to="/account/instellingen" />
      </Route>

      {/* ── Vandaag (Sectie 1) ─────────────────────────────────────────────── */}
      <Route path="/vandaag" component={VandaagPage} />
      <Route path="/vandaag/updates">
        <Redirect to="/vandaag" />
      </Route>
      <Route path="/vandaag/acties">
        <Redirect to="/vandaag" />
      </Route>
      <Route path="/vandaag/samen">
        <Redirect to="/vandaag" />
      </Route>
      <Route path="/vandaag/nieuws">
        <Redirect to="/vandaag" />
      </Route>

      {/* ── Kansen (Sectie 2) ─────────────────────────────────────────────── */}
      <Route path="/kansen/opdrachten" component={AanbestedingenPage} />
      <Route path="/kansen/subsidies" component={FinancieringPage} />
      <Route path="/kansen/in-de-buurt" component={KansenInDeBuurtPage} />
      <Route path="/kansen/samenwerkingen">
        <Redirect to="/network" />
      </Route>

      {/* ── Regels (Sectie 3) ─────────────────────────────────────────────── */}
      <Route path="/regels/updates" component={IntelPage} />
      <Route path="/regels/help" component={RegelsHelpPage} />
      <Route path="/regels/help/:flowId" component={RegelsHelpFlowPage} />
      <Route path="/regels/check" component={CheckSituatiePage} />
      <Route path="/regels/documenten" component={BriefAnalysePage} />
      <Route path="/regels/woo" component={WooBibliotheekPage} />

      {/* ── Groei (Sectie 4) ──────────────────────────────────────────────── */}
      <Route path="/groei/zichtbaarheid" component={ProVisibilitySettingsPage} />
      <Route path="/groei/profiel" component={BedrijfsprofielPage} />
      <Route path="/groei/website-check" component={WebsiteScanPage} />

      {/* ── Mijn account (Sectie 5) ───────────────────────────────────────── */}
      <Route path="/account/voortgang">
        <BinnenkortPage titel="Voortgang" />
      </Route>
      <Route path="/account/instellingen" component={PrivacyDashboardPage} />
      <Route path="/account/affiliate" component={AffiliatePage} />

      {/* ── Beheer (admin) ────────────────────────────────────────────────── */}
      <Route path="/admin" component={AdminIndexPage} />
      <Route path="/admin/woo" component={AdminWooPage} />
      <Route path="/admin/regios" component={AdminRegiosPage} />
      <Route path="/admin/inzicht" component={AdminInzichtPage} />
      <Route path="/admin/blogs" component={AdminBlogsPage} />
      <Route path="/admin/commissions" component={AdminCommissionsPage} />
      <Route path="/admin/users" component={AdminUsersPage} />
      <Route path="/admin/regio-deals" component={RegiodealsAdminPage} />
      <Route path="/admin/ondernemers" component={AdminOndernemersPage} />
      <Route path="/admin/intel" component={AdminIntelPage} />
      <Route path="/admin/wetgeving" component={AdminWetgevingPage} />
      <Route path="/admin/cursussen" component={AdminCursussenPage} />

      {/* ── Overige authenticeerde routes (intern / deeplink) ─────────────── */}
      <Route path="/onboarding" component={OnboardingPage} />
      <Route path="/aan-de-slag" component={AanDeSlagPage} />
      <Route path="/network" component={NetworkPage} />
      <Route path="/community" component={CommunityPage} />
      <Route path="/chat" component={ChatPage} />
      <Route path="/regiobot" component={RegioBotPage} />
      <Route path="/cooperative" component={CooperativePage} />
      <Route path="/woo-bot" component={WooBotPage} />
      <Route path="/woo-wizard" component={WooWizardPage} />
      <Route path="/regiocrew" component={RegioCrewPage} />
      <Route path="/leden" component={LedenPage} />
      <Route path="/beleidsmonitor" component={BeleidsmonitorPage} />
      <Route path="/lokale-basischeck" component={LokaleBasischeckPage} />
      <Route path="/kansen-markt" component={KansenMarktPage} />
      <Route path="/kansen/gemeente-updates" component={GemeenteUpdatesPage} />
      <Route path="/kansen/regio-deals" component={RegiodealsPage} />
      <Route path="/informatie/regelkaart" component={RegelkaartPage} />
      <Route path="/informatie/kennisbank" component={KennisbankPage} />
      <Route path="/regelgeving-verkenner" component={RegelgevingVerkennerPage} />
      <Route path="/zichtbaarheid/website-onderhoud" component={WebsiteOnderhoudPage} />
      <Route path="/lokaal-marktplaats" component={LokaalMarktplaatsPage} />
      <Route path="/wetgeving-indienen" component={WetgevingIndienenPage} />
      <Route path="/wetgeving/publicaties" component={WetgevingPublicatiesPage} />

      <Route component={NotFound} />
    </Switch>
  );
}

// Central guard: shows loading, redirects to /login or /first-login when needed
function AuthGuard({ children }: { children: React.ReactNode }) {
  const { user, isLoading } = useAuth();
  const [, setLocation] = useLocation();

  if (isLoading) {
    return (
      <div className="flex-1 p-6 space-y-4">
        <Skeleton className="h-8 w-48" />
        <Skeleton className="h-4 w-full" />
        <Skeleton className="h-4 w-3/4" />
        <Skeleton className="h-64 w-full" />
      </div>
    );
  }

  if (!user) {
    setLocation("/login");
    return null;
  }

  if (user.mustCompleteOnboarding) {
    setLocation("/first-login");
    return null;
  }

  return <>{children}</>;
}

function AppContent() {
  useContentProtection();
  const [isHomePage] = useRoute("/");
  const [isLoginPage] = useRoute("/login");
  const [isRegisterPage] = useRoute("/register");
  const [isStartPage] = useRoute("/start");
  const [isLidmaatschapPage] = useRoute("/lidmaatschap");
  const [isPaymentSuccessPage] = useRoute("/betaling-geslaagd");
  const [isFirstLoginPage] = useRoute("/first-login");
  const [isPrivacyPage] = useRoute("/privacy");
  const [isVoorwaardenPage] = useRoute("/voorwaarden");
  const [isBasischeckPage] = useRoute("/basischeck");
  const [isBlogDetailPage] = useRoute("/blog/:slug");
  const [isBlogsPage] = useRoute("/blogs");
  const [isForgotPasswordPage] = useRoute("/forgot-password");
  const [isResetPasswordPage] = useRoute("/reset-password");
  const [isDisclaimerPage] = useRoute("/disclaimer");
  const [isCookiebeleidPage] = useRoute("/cookiebeleid");
  const [isRegioAnalysePage] = useRoute("/regio-analyse");
  const [isKoopLokaalPage] = useRoute("/koop-lokaal");
  const [isGezondPijlerPage] = useRoute("/gezond/:slug");

  // /lidmaatschap krijgt de top-nav, maar blijft publiek bereikbaar.
  // Daarom NIET in PUBLIC_ROUTES en NIET in AuthGuard, maar in een eigen
  // layout-tak hieronder.
  const isPublicRoute = isHomePage || isLoginPage || isRegisterPage || isStartPage || isPaymentSuccessPage || isFirstLoginPage || isPrivacyPage || isVoorwaardenPage || isBasischeckPage || isBlogDetailPage || isBlogsPage || isForgotPasswordPage || isResetPasswordPage || isDisclaimerPage || isCookiebeleidPage || isRegioAnalysePage || isKoopLokaalPage || isGezondPijlerPage;

  if (isPublicRoute) {
    return <PublicRouter />;
  }

  // /lidmaatschap: publieke pagina met OpenRegio top-nav (top-nav past zich
  // aan op basis van of de gebruiker is ingelogd)
  if (isLidmaatschapPage) {
    return (
      <div className="openregio-page" data-testid="layout-openregio-topnav-public">
        <OpenRegioTopNav />
        <main className="flex-1 protected-content">
          <LidmaatschapPage />
        </main>
      </div>
    );
  }

  // Alle ingelogde pagina's gebruiken de OpenRegio top-nav layout (geen sidebar)
  return (
    <div className="openregio-page" data-testid="layout-openregio-topnav">
      <OpenRegioTopNav />
      <main className="flex-1 protected-content openregio-page-shell">
        <AuthGuard>
          <AuthenticatedRouter />
        </AuthGuard>
      </main>
    </div>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <ErrorBoundary>
          <AppContent />
        </ErrorBoundary>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
