import { Link } from "wouter";
import {
  Bell,
  CheckCircle2,
  FolderOpen,
  Target,
  FileText,
  AlertCircle,
  Users,
  MessageSquare,
  Megaphone,
  ClipboardList,
  ArrowRight,
} from "lucide-react";
import { useAuth } from "@/hooks/useAuth";
import { usePageTitle } from "@/hooks/usePageTitle";
import { Skeleton } from "@/components/ui/skeleton";

const kpis = [
  { title: "Updates", value: "3", meta: "nieuw", icon: Bell },
  { title: "Acties", value: "2", meta: "open", icon: CheckCircle2 },
  { title: "Kansen", value: "4", meta: "relevant", icon: Target },
  { title: "Dossiers", value: "1", meta: "lopend", icon: FolderOpen },
];

const aandachtItems = [
  {
    badge: "Regelupdate",
    badgeClass: "bg-blue-50 text-blue-700",
    title: "Nieuwe terrasregels centrum",
    description: "De gemeente heeft nieuwe regels voor terrassen gepubliceerd.",
    cta: "Bekijk update",
    icon: FileText,
    iconClass: "bg-blue-50 text-blue-600",
  },
  {
    badge: "Actie nodig",
    badgeClass: "bg-orange-50 text-orange-700",
    title: "Antwoord binnen op documentverzoek",
    description: "Gemeente vraagt om aanvullende informatie. Reageer vóór 28 mei.",
    cta: "Nu reageren",
    icon: AlertCircle,
    iconClass: "bg-orange-50 text-orange-600",
  },
  {
    badge: "Kans",
    badgeClass: "bg-green-50 text-green-700",
    title: "Lokale zomeractie zoekt partners",
    description: "Doe mee aan de promotiecampagne en bereik meer klanten samen.",
    cta: "Bekijk kans",
    icon: Users,
    iconClass: "bg-green-50 text-green-600",
  },
];

const vragenItems = [
  {
    title: "Wie heeft ervaring met terrasvergunningen?",
    meta: "2 reacties",
    when: "Vandaag",
    icon: MessageSquare,
    iconClass: "bg-blue-50 text-blue-600",
  },
  {
    title: "Gezocht: partner voor lokale flyeractie",
    meta: "4 ondernemers aangehaakt",
    when: "Gisteren",
    icon: Megaphone,
    iconClass: "bg-green-50 text-green-600",
  },
  {
    title: "Meer ondernemers last van afvalheffing",
    meta: "3 reacties",
    when: "2 dagen geleden",
    icon: ClipboardList,
    iconClass: "bg-purple-50 text-purple-600",
  },
];

const acties = [
  { title: "Reageer op documentverzoek gemeente", due: "Vóór 28 mei", color: "bg-orange-500" },
  { title: "Lees nieuwe terrasregels centrum", due: "Vóór 31 mei", color: "bg-blue-500" },
  { title: "Geef input op dossier Terrasbeleid", due: "Vóór 5 juni", color: "bg-blue-500" },
  { title: "Update je bedrijfsgegevens", due: "Wanneer jij wilt", color: "bg-slate-400" },
];

const dossiers = [
  {
    title: "Handhaving bedrijventerrein",
    status: "In opbouw",
    statusClass: "bg-blue-50 text-blue-700",
    description: "Samen werken aan duidelijke en eerlijke handhaving.",
    members: "12 aangesloten",
    cta: "Bekijk dossier",
  },
  {
    title: "Terrasbeleid binnenstad",
    status: "Lopend",
    statusClass: "bg-green-50 text-green-700",
    description: "Impact nieuwe regels en praktische oplossingen.",
    members: "27 aangesloten",
    cta: "Bekijk dossier",
  },
  {
    title: "Afvalheffing ondernemerszone",
    status: "Verkennen",
    statusClass: "bg-purple-50 text-purple-700",
    description: "Onderzoeken en aanpak van knelpunten.",
    members: "18 aangesloten",
    cta: "Aansluiten",
  },
];

function CtaButton({ children }: { children: React.ReactNode }) {
  return (
    <button
      type="button"
      className="inline-flex items-center gap-2 rounded-xl border border-slate-200 bg-white px-4 py-2 text-sm font-medium text-slate-700 transition hover:border-slate-300 hover:bg-slate-50"
    >
      {children}
      <ArrowRight className="h-4 w-4" />
    </button>
  );
}

export default function VandaagPage() {
  usePageTitle("Vandaag");
  const { user, isLoading } = useAuth();

  if (isLoading) {
    return (
      <div className="space-y-6" data-testid="skeleton-vandaag">
        <Skeleton className="h-12 w-64" />
        <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
          {[1, 2, 3, 4].map((i) => (
            <Skeleton key={i} className="h-28 rounded-3xl" />
          ))}
        </div>
      </div>
    );
  }

  if (!user) return null;

  const firstName = user.firstName || "ondernemer";

  return (
    <div className="space-y-6 pb-8" data-testid="page-vandaag">
      <section className="space-y-2">
        <div className="flex flex-col gap-2 sm:flex-row sm:items-end sm:justify-between">
          <div>
            <h1 className="text-3xl font-bold tracking-tight text-slate-900">Vandaag</h1>
            <p className="mt-1 text-sm text-slate-600">
              Dit speelt nu in jouw regio, sector en dossiers, {firstName}.
            </p>
          </div>
          <Link
            href="/regels/documenten"
            className="inline-flex items-center justify-center rounded-xl bg-blue-600 px-4 py-2 text-sm font-semibold text-white transition hover:bg-blue-700"
          >
            Document check starten
          </Link>
        </div>
      </section>

      <section className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
        {kpis.map((item) => {
          const Icon = item.icon;
          return (
            <div
              key={item.title}
              className="rounded-3xl border border-slate-200 bg-white p-5 shadow-sm"
              data-testid={`kpi-${item.title.toLowerCase()}`}
            >
              <div className="flex items-center gap-4">
                <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-blue-50 text-blue-600">
                  <Icon className="h-6 w-6" />
                </div>
                <div>
                  <div className="flex items-baseline gap-2">
                    <span className="text-3xl font-bold text-slate-900">{item.value}</span>
                    <span className="text-sm text-slate-500">{item.meta}</span>
                  </div>
                  <p className="mt-1 text-base font-medium text-slate-700">{item.title}</p>
                </div>
              </div>
            </div>
          );
        })}
      </section>

      <section className="space-y-4">
        <div className="flex items-center justify-between gap-3">
          <h2 className="text-2xl font-semibold tracking-tight text-slate-900">Wat vraagt nu aandacht?</h2>
          <Link href="/regels/updates" className="text-sm font-medium text-blue-600 hover:text-blue-700">
            Bekijk alles
          </Link>
        </div>
        <div className="grid gap-4 xl:grid-cols-3">
          {aandachtItems.map((item) => {
            const Icon = item.icon;
            return (
              <article key={item.title} className="rounded-3xl border border-slate-200 bg-white p-5 shadow-sm">
                <div className="flex items-start justify-between gap-4">
                  <div>
                    <span className={`inline-flex rounded-full px-3 py-1 text-xs font-semibold ${item.badgeClass}`}>
                      {item.badge}
                    </span>
                    <h3 className="mt-4 text-xl font-semibold leading-snug text-slate-900">{item.title}</h3>
                  </div>
                  <div className={`flex h-12 w-12 items-center justify-center rounded-2xl ${item.iconClass}`}>
                    <Icon className="h-6 w-6" />
                  </div>
                </div>
                <p className="mt-3 min-h-[48px] text-sm leading-6 text-slate-600">{item.description}</p>
                <div className="mt-5">
                  <CtaButton>{item.cta}</CtaButton>
                </div>
              </article>
            );
          })}
        </div>
      </section>

      <section className="rounded-3xl border border-slate-200 bg-white p-5 shadow-sm">
        <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
          <div>
            <h2 className="text-2xl font-semibold tracking-tight text-slate-900">Samenwerken & vragen</h2>
            <p className="mt-1 text-sm text-slate-600">
              Loop je ergens op vast of zoek je samenwerking? Haak direct aan.
            </p>
          </div>
          <div className="flex flex-wrap gap-3">
            <button type="button" className="rounded-xl bg-blue-600 px-4 py-2 text-sm font-semibold text-white hover:bg-blue-700">Stel een vraag</button>
            <button type="button" className="rounded-xl border border-slate-200 bg-white px-4 py-2 text-sm font-semibold text-slate-700 hover:bg-slate-50">Plaats oproep</button>
            <button type="button" className="rounded-xl border border-slate-200 bg-white px-4 py-2 text-sm font-semibold text-slate-700 hover:bg-slate-50">Bekijk alles</button>
          </div>
        </div>
        <div className="mt-5 grid gap-4 xl:grid-cols-3">
          {vragenItems.map((item) => {
            const Icon = item.icon;
            return (
              <article key={item.title} className="rounded-3xl border border-slate-200 bg-slate-50/70 p-5">
                <div className="flex items-start gap-4">
                  <div className={`flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl ${item.iconClass}`}>
                    <Icon className="h-5 w-5" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <h3 className="text-lg font-semibold leading-snug text-slate-900">{item.title}</h3>
                    <div className="mt-4 flex items-center justify-between gap-3 text-sm text-slate-500">
                      <span>{item.meta}</span>
                      <span>{item.when}</span>
                    </div>
                  </div>
                </div>
              </article>
            );
          })}
        </div>
      </section>

      <section className="grid gap-4 xl:grid-cols-[1.1fr,1.4fr]">
        <div className="rounded-3xl border border-slate-200 bg-white p-5 shadow-sm">
          <div className="flex items-center justify-between gap-3">
            <h2 className="text-2xl font-semibold tracking-tight text-slate-900">Acties voor jou</h2>
            <Link href="/vandaag" className="text-sm font-medium text-blue-600 hover:text-blue-700">
              Bekijk alle acties
            </Link>
          </div>
          <div className="mt-4 space-y-3">
            {acties.map((item) => (
              <div key={item.title} className="flex items-center gap-3 rounded-2xl border border-slate-200 p-3">
                <span className={`h-2.5 w-2.5 rounded-full ${item.color}`} />
                <div className="min-w-0 flex-1">
                  <p className="truncate text-sm font-medium text-slate-800">{item.title}</p>
                  <p className="text-sm text-slate-500">{item.due}</p>
                </div>
                <button type="button" className="rounded-xl border border-slate-200 px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50">
                  Nu doen
                </button>
              </div>
            ))}
          </div>
        </div>

        <div className="rounded-3xl border border-slate-200 bg-white p-5 shadow-sm">
          <div className="flex items-center justify-between gap-3">
            <h2 className="text-2xl font-semibold tracking-tight text-slate-900">Gezamenlijke dossiers</h2>
            <Link href="/regels/woo" className="text-sm font-medium text-blue-600 hover:text-blue-700">
              Bekijk alle dossiers
            </Link>
          </div>
          <div className="mt-4 grid gap-4 lg:grid-cols-3">
            {dossiers.map((item) => (
              <article key={item.title} className="rounded-3xl border border-slate-200 p-5">
                <span className={`inline-flex rounded-full px-3 py-1 text-xs font-semibold ${item.statusClass}`}>
                  {item.status}
                </span>
                <h3 className="mt-4 text-xl font-semibold leading-snug text-slate-900">{item.title}</h3>
                <p className="mt-3 min-h-[72px] text-sm leading-6 text-slate-600">{item.description}</p>
                <p className="mt-3 text-sm text-slate-500">{item.members}</p>
                <div className="mt-5">
                  <CtaButton>{item.cta}</CtaButton>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
