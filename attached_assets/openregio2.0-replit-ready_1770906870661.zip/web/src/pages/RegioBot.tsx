import { useEffect, useState } from "react";
import { getToken } from "../auth";
import { getTemplates, renderTemplate, uploadDoc } from "../api";

export default function RegioBot() {
  const token = getToken()!;
  const [templates, setTemplates] = useState<any[]>([]);
  const [slug, setSlug] = useState("woo-zuiver");
  const [vars, setVars] = useState({
    onderwerp: "het verkrijgen van onroerende zaken door de gemeente",
    periode: "2024",
    gemeente: "Gemeente …",
    scope: "- Overzicht van objecten\n- Besluiten\n- Taxaties",
    postadres: "Straat 1",
    woonplaats: "Plaats",
    naam: "Naam"
  });
  const [out, setOut] = useState("");
  const [file, setFile] = useState<File | null>(null);
  const [tags, setTags] = useState("woo");
  const [uploadMsg, setUploadMsg] = useState("");

  useEffect(() => {
    getTemplates().then((r) => setTemplates(r.templates || []));
  }, []);

  async function gen() {
    const r = await renderTemplate(slug, vars);
    setOut(r.rendered || "");
  }

  async function doUpload() {
    if (!file) return alert("Kies een bestand.");
    const r = await uploadDoc(token, file, tags);
    if (r.ok) setUploadMsg("✅ Upload opgeslagen in jouw WOO-bibliotheek.");
    else setUploadMsg("❌ Upload mislukt.");
  }

  return (
    <div className="container">
      <div className="card">
        <h2 style={{marginTop:0}}>RegioBot</h2>
        <div className="muted">
          AI is de motor. Jij blijft aan zet. Genereer een zuiver Woo-verzoek of upload documenten voor je bibliotheek.
        </div>
      </div>

      <div className="grid" style={{gridTemplateColumns:"1fr 1fr", marginTop:16}}>
        <div className="card">
          <b>Woo-template generator</b>
          <div className="muted small" style={{marginTop:6}}>
            Geen juridische strijd. Eerst zuiver verzoek. Daarna pas toetsen.
          </div>

          <div style={{marginTop:10}}>
            <select className="input" value={slug} onChange={(e)=>setSlug(e.target.value)}>
              {templates.map(t => <option key={t.id} value={t.slug}>{t.title}</option>)}
            </select>
          </div>

          <div className="grid" style={{marginTop:10}}>
            {Object.keys(vars).map((k) => (
              <input
                key={k}
                className="input"
                placeholder={k}
                value={(vars as any)[k]}
                onChange={(e)=>setVars({ ...vars, [k]: e.target.value } as any)}
              />
            ))}
            <button className="btn primary" onClick={gen}>Genereer tekst</button>
          </div>

          <div className="muted small" style={{marginTop:10}}>
            Versturen doe je zelf. OpenRegio faciliteert templates en inzicht.
          </div>
        </div>

        <div className="card">
          <b>Document upload</b>
          <div className="muted small" style={{marginTop:6}}>Upload PDF/ZIP naar jouw WOO-bibliotheek.</div>

          <div className="grid" style={{marginTop:10}}>
            <input className="input" placeholder="Tags (komma)" value={tags} onChange={(e)=>setTags(e.target.value)} />
            <input type="file" className="input" onChange={(e)=>setFile(e.target.files?.[0] || null)} />
            <button className="btn primary" onClick={doUpload}>Upload</button>
            {uploadMsg ? <div className="muted">{uploadMsg}</div> : null}
          </div>

          <hr />
          <b>Output</b>
          <textarea className="input" style={{height:280, fontFamily:"ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas"}} value={out} readOnly />
        </div>
      </div>
    </div>
  );
}
