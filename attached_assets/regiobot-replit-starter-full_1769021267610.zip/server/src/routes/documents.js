import multer from 'multer';
import { sql } from '../db.js';
import { extractTextFromPDF } from '../ingest/extract.js';
import { chunkText } from '../ingest/chunk.js';
import { embedTexts } from '../openai.js';

const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 25 * 1024 * 1024 } });

export const uploadMiddleware = upload.single('file');

export async function uploadDocument(req, res) {
  try {
    const { org_id, region, title } = req.body;
    if (!org_id) return res.status(400).json({ error: 'org_id required' });
    if (!req.file) return res.status(400).json({ error: 'file required' });

    const { text, needsOcr } = await extractTextFromPDF(req.file.buffer);

    const docRes = await sql(
      `INSERT INTO documents (org_id, region, title, source_type, needs_ocr, metadata_json)
       VALUES ($1,$2,$3,'upload',$4,$5) RETURNING id`,
      [org_id, region || null, title || req.file.originalname, needsOcr, JSON.stringify({ filename: req.file.originalname })]
    );
    const document_id = docRes.rows[0].id;

    const chunks = chunkText(text, { maxTokens: 1100, overlapTokens: 220 });
    if (!chunks.length) {
      await sql(`UPDATE documents SET needs_ocr = TRUE WHERE id = $1`, [document_id]);
      return res.json({ document_id, indexed: 0, needs_ocr: true });
    }

    const BATCH = 64;
    let indexed = 0;

    for (let i = 0; i < chunks.length; i += BATCH) {
      const batch = chunks.slice(i, i + BATCH);
      const embeddings = await embedTexts(batch);

      for (let j = 0; j < batch.length; j++) {
        const chunkRes = await sql(
          `INSERT INTO chunks (document_id, chunk_index, text, metadata_json)
           VALUES ($1,$2,$3,$4) RETURNING id`,
          [document_id, i + j, batch[j], JSON.stringify({})]
        );
        const chunk_id = chunkRes.rows[0].id;

        await sql(
          `INSERT INTO embeddings (chunk_id, embedding) VALUES ($1, $2::vector)`,
          [chunk_id, embeddings[j]]
        );
        indexed++;
      }
    }

    await sql(
      `INSERT INTO audit_logs (org_id, action, payload) VALUES ($1,'document_uploaded',$2)`,
      [org_id, JSON.stringify({ document_id, indexed, needs_ocr })]
    );

    return res.json({ document_id, indexed, needs_ocr });
  } catch (e) {
    console.error(e);
    return res.status(500).json({ error: String(e.message || e) });
  }
}
