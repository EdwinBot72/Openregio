import { useState } from "react";
import { createMonitor } from "../api";

export default function Admin() {
  const [region, setRegion] = useState("Nederland");
  const [title, setTitle] = useState("Nieuwe update");
  const [summary, setSummary] = useState("Korte samenvatting (max 2 zinnen).");
  const [tags, setTags] = useState("beleid");
  const [msg, setMsg] = useState("");

  async function add() {
    const r = await createMonitor({ region, title, summary, tags });
    setMsg(r.ok ? "✅ Item toegevoegd." : "❌ Fout.");
  }

  return (
    <div className="container">
      <div className="card">
        <h2 style={{marginTop:0}}>Admin (MVP)</h2>
        <div className="muted">Maak monitor-items aan om de feed te vullen. Later: echte bronnen + rollen.</div>
      </div>

      <div className="card" style={{marginTop:16}}>
        <div className="grid">
          <input className="input" value={region} onChange={(e)=>setRegion(e.target.value)} placeholder="Regio (bijv. Amsterdam)" />
          <input className="input" value={title} onChange={(e)=>setTitle(e.target.value)} placeholder="Titel" />
          <input className="input" value={tags} onChange={(e)=>setTags(e.target.value)} placeholder="Tags (komma)" />
          <textarea className="input" style={{height:120}} value={summary} onChange={(e)=>setSummary(e.target.value)} placeholder="Samenvatting" />
          <button className="btn primary" onClick={add}>Toevoegen</button>
          {msg ? <div className="muted">{msg}</div> : null}
        </div>
      </div>
    </div>
  );
}
