import { useState } from "react";
import { Link } from "react-router-dom";
import { login } from "../api";
import { setToken } from "../auth";

export default function Home() {
  const [postcode, setPostcode] = useState("");
  const [email, setEmail] = useState("");
  const [region, setRegion] = useState<string>("");

  async function doCheck() {
    if (!email) return alert("Vul je e-mail in.");
    const r = await login(email, postcode);
    if (r?.token) {
      setToken(r.token);
      setRegion(r.region || "Nederland");
    }
  }

  return (
    <div className="container">
      <div className="hero">
        <h1>Ondernemen met voorsprong in je eigen regio.</h1>
        <p>
          OpenRegio combineert <b>beleidsinzicht</b>, <b>regionale samenwerking</b> en <b>praktische weerbaarheid</b>.
          Jij blijft menselijk ondernemen — met betere info en kortere lijnen.
        </p>
        <div className="kpis">
          <div className="kpi">Regio-check in 30 sec</div>
          <div className="kpi">WOO templates + bibliotheek</div>
          <div className="kpi">RegioBot (AI als motor)</div>
          <div className="kpi">Werk blijft lokaal</div>
        </div>

        <div style={{display:"grid", gridTemplateColumns:"1fr 1fr auto", gap:10, marginTop:16, alignItems:"center"}}>
          <input className="input" placeholder="E-mail" value={email} onChange={(e)=>setEmail(e.target.value)} />
          <input className="input" placeholder="Postcode (optioneel)" value={postcode} onChange={(e)=>setPostcode(e.target.value)} />
          <button className="btn orange" onClick={doCheck}>Start regio-check</button>
        </div>

        {region && (
          <div style={{marginTop:12}}>
            <span className="badge">Jouw regio: <b>{region}</b></span>{" "}
            <Link className="btn primary" to="/app">Door naar dashboard</Link>
          </div>
        )}
      </div>

      <div className="grid" style={{gridTemplateColumns:"repeat(3, 1fr)", marginTop:18}}>
        <div className="card">
          <b>Inzicht vóór je het nodig hebt</b>
          <div className="muted" style={{marginTop:6}}>
            RegioBot filtert publicaties en documenten. Jij ziet wat relevant is, zonder eindeloos zoeken.
          </div>
        </div>
        <div className="card">
          <b>Regionaal netwerk dat werkt</b>
          <div className="muted" style={{marginTop:6}}>
            Doorverwijzing binnen de regio, zonder advertentie-trucs. Menselijk, direct, praktisch.
          </div>
        </div>
        <div className="card">
          <b>Back to Basic (zonder terug te gaan)</b>
          <div className="muted" style={{marginTop:6}}>
            Minder kwetsbaar. Meer continuïteit. Een toolkit die je bedrijf draaiend houdt.
          </div>
        </div>
      </div>

      <div className="card" style={{marginTop:16}}>
        <div style={{display:"flex", justifyContent:"space-between", alignItems:"center", gap:12, flexWrap:"wrap"}}>
          <div>
            <b>Al een account?</b>
            <div className="muted">Log in en ga direct naar Monitor, RegioBot en je WOO-bibliotheek.</div>
          </div>
          <Link className="btn primary" to="/login">Inloggen</Link>
        </div>
      </div>

      <div className="muted small" style={{marginTop:14}}>
        OpenRegio faciliteert templates en inzicht. Geen juridisch advies, geen vertegenwoordiging. Jij blijft aan zet.
      </div>
    </div>
  );
}
