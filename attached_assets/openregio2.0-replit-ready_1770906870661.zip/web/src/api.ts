export type User = { id: string; email: string; region: string; createdAt: number };

export async function login(email: string, postcode?: string) {
  const r = await fetch("/api/auth/login", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ email, postcode })
  });
  return r.json();
}

export async function me(token: string) {
  const r = await fetch("/api/me", { headers: { Authorization: `Bearer ${token}` } });
  return r.json();
}

export async function getMonitor(region: string) {
  const r = await fetch(`/api/monitor?region=${encodeURIComponent(region)}`);
  return r.json();
}

export async function createMonitor(item: any) {
  const r = await fetch("/api/monitor", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(item)
  });
  return r.json();
}

export async function getTemplates() {
  const r = await fetch("/api/templates");
  return r.json();
}

export async function renderTemplate(slug: string, vars: Record<string, any>) {
  const r = await fetch(`/api/templates/${slug}/render`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(vars)
  });
  return r.json();
}

export async function uploadDoc(token: string, file: File, tags: string) {
  const fd = new FormData();
  fd.append("file", file);
  fd.append("tags", tags);

  const r = await fetch("/api/documents/upload", {
    method: "POST",
    headers: { Authorization: `Bearer ${token}` },
    body: fd
  });
  return r.json();
}

export async function listDocs(token: string, region: string) {
  const r = await fetch(`/api/documents?region=${encodeURIComponent(region)}`, {
    headers: { Authorization: `Bearer ${token}` }
  });
  return r.json();
}

export async function summarizeDoc(token: string, id: string, text: string) {
  const r = await fetch(`/api/documents/${id}/summarize`, {
    method: "POST",
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
    body: JSON.stringify({ text })
  });
  return r.json();
}
