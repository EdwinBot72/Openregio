import { ask } from '../rag/answer.js';

export async function askRoute(req, res) {
  try {
    const { org_id, query, k } = req.body || {};
    if (!org_id) return res.status(400).json({ error: 'org_id required' });
    if (!query) return res.status(400).json({ error: 'query required' });

    const out = await ask({ org_id, query, k: k || Number(process.env.TOP_K || 8) });
    return res.json(out);
  } catch (e) {
    console.error(e);
    return res.status(500).json({ error: String(e.message || e) });
  }
}
