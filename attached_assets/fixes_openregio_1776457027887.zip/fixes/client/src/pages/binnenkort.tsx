import { usePageTitle } from "@/hooks/usePageTitle";
import { useLocation } from "wouter";
import { Clock, ArrowLeft } from "lucide-react";

interface Props {
  titel?: string;
  beschrijving?: string;
}

export default function BinnenkortPage({
  titel = "Binnenkort beschikbaar",
  beschrijving,
}: Props) {
  usePageTitle(titel);
  const [, setLocation] = useLocation();

  const standaardBeschrijving =
    beschrijving ||
    "We zijn druk bezig met het bouwen van deze functie. Kom snel terug!";

  return (
    <div className="flex flex-col items-center justify-center min-h-[50vh] gap-6 text-center px-4 py-12">
      <div className="w-14 h-14 rounded-2xl bg-primary/10 flex items-center justify-center">
        <Clock className="h-7 w-7 text-primary" />
      </div>

      <div className="space-y-2 max-w-sm">
        <h1 className="text-2xl font-bold">{titel}</h1>
        <p className="text-sm text-muted-foreground leading-relaxed">
          {standaardBeschrijving}
        </p>
      </div>

      <button
        onClick={() => setLocation("/vandaag")}
        className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors mt-2"
      >
        <ArrowLeft className="h-4 w-4" />
        Terug naar vandaag
      </button>
    </div>
  );
}
