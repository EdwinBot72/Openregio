import { Routes, Route, Link, useLocation, Navigate } from "react-router-dom";
import Home from "./pages/Home";
import Login from "./pages/Login";
import Dashboard from "./pages/Dashboard";
import Monitor from "./pages/Monitor";
import RegioBot from "./pages/RegioBot";
import Library from "./pages/Library";
import Admin from "./pages/Admin";
import { getToken, clearToken } from "./auth";

function Nav() {
  const token = getToken();
  return (
    <div className="nav">
      <div className="nav-inner">
        <div className="nav-left">
          <div className="logo">OR</div>
          <strong>OpenRegio 2.0</strong>
          <span className="muted small">Menselijk. Regionaal. Met voorsprong.</span>
        </div>
        <div style={{display:"flex", gap:10, alignItems:"center"}}>
          <Link className="btn" to="/">Home</Link>
          {token ? (
            <>
              <Link className="btn" to="/app">Dashboard</Link>
              <button className="btn" onClick={() => { clearToken(); location.href="/"; }}>Uitloggen</button>
            </>
          ) : (
            <Link className="btn primary" to="/login">Inloggen</Link>
          )}
        </div>
      </div>
    </div>
  );
}

function RequireAuth({ children }: { children: JSX.Element }) {
  const token = getToken();
  if (!token) return <Navigate to="/login" replace />;
  return children;
}

export default function App() {
  return (
    <>
      <Nav />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/login" element={<Login />} />

        <Route path="/app" element={<RequireAuth><Dashboard /></RequireAuth>} />
        <Route path="/app/monitor" element={<RequireAuth><Monitor /></RequireAuth>} />
        <Route path="/app/regiobot" element={<RequireAuth><RegioBot /></RequireAuth>} />
        <Route path="/app/library" element={<RequireAuth><Library /></RequireAuth>} />
        <Route path="/app/admin" element={<RequireAuth><Admin /></RequireAuth>} />

        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </>
  );
}
