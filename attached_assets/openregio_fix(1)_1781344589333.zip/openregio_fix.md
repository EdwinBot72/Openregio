REPLIT FIX PROMPT - OPENREGIO

Fix only:
1. Mollie prices basic 14.95 pro 59 excl btw
2. No free basic registration
3. requireAuth/basic/pro/coaching/admin
4. Protect API routes
5. No fallback plan basic
6. npm run check + build
